package com.devtec.gestionstages.service;

import com.devtec.gestionstages.dto.ConventionResponse;
import com.devtec.gestionstages.entity.*;
import com.devtec.gestionstages.exception.BusinessException;
import com.devtec.gestionstages.exception.ResourceNotFoundException;
import com.devtec.gestionstages.repository.CandidatureRepository;
import com.devtec.gestionstages.repository.ConventionStageRepository;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDate;
import java.util.Optional;

import static com.devtec.gestionstages.service.DonneesTest.*;
import static org.assertj.core.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
@DisplayName("ConventionStageService : numéro unique NN-M-AAAA et génération des conventions")
class ConventionStageServiceTest {

    @Mock private ConventionStageRepository conventionRepository;
    @Mock private CandidatureRepository candidatureRepository;
    @InjectMocks private ConventionStageService service;

    // ------------------------------------------------------------------ formaterNumero

    @Nested
    @DisplayName("formaterNumero")
    class FormaterNumero {

        @Test
        @DisplayName("Exemple de l'énoncé : 3e stagiaire de juin 2026 → 03-6-2026")
        void exempleEnonce() {
            assertThat(ConventionStageService.formaterNumero(3, 6, 2026)).isEqualTo("03-6-2026");
        }

        @Test
        @DisplayName("Au-delà de 99, le numéro n'est pas tronqué")
        void numeroATroisChiffres() {
            assertThat(ConventionStageService.formaterNumero(100, 1, 2027)).isEqualTo("100-1-2027");
        }

        @Test
        @DisplayName("Un mois autre que 1 ou 6 est refusé")
        void moisInvalide() {
            assertThatIllegalArgumentException()
                    .isThrownBy(() -> ConventionStageService.formaterNumero(1, 3, 2026))
                    .withMessageContaining("1 ou 6");
        }

        @Test
        @DisplayName("Un numéro séquentiel nul ou négatif est refusé")
        void sequenceNonPositive() {
            assertThatIllegalArgumentException()
                    .isThrownBy(() -> ConventionStageService.formaterNumero(0, 6, 2026));
        }
    }

    // ------------------------------------------------------------------ moisRecrutement

    @ParameterizedTest(name = "stage débutant le {0} → session {1}")
    @CsvSource({
            "2026-01-15, 1",
            "2026-05-31, 1",
            "2026-06-01, 6",
            "2026-09-30, 6",
            "2026-12-01, 6"
    })
    @DisplayName("moisRecrutement : janvier (1) avant juin, sinon juin (6)")
    void moisRecrutement(LocalDate debut, int moisAttendu) {
        assertThat(ConventionStageService.moisRecrutement(debut)).isEqualTo(moisAttendu);
    }

    // ------------------------------------------------------------------ prochainNumeroSequentiel

    @Test
    @DisplayName("Première convention d'une session → numéro 1")
    void premiereConventionDeLaSession() {
        when(conventionRepository.findMaxNumSequentiel(6, 2026)).thenReturn(0);
        assertThat(service.prochainNumeroSequentiel(6, 2026)).isEqualTo(1);
    }

    @Test
    @DisplayName("Après la convention n°2 → numéro 3")
    void conventionSuivante() {
        when(conventionRepository.findMaxNumSequentiel(1, 2027)).thenReturn(2);
        assertThat(service.prochainNumeroSequentiel(1, 2027)).isEqualTo(3);
    }

    @Test
    @DisplayName("Session invalide (mois 3) → exception, la base n'est pas interrogée")
    void sessionInvalide() {
        assertThatIllegalArgumentException().isThrownBy(() -> service.prochainNumeroSequentiel(3, 2026));
        verifyNoInteractions(conventionRepository);
    }

    // ------------------------------------------------------------------ generer

    @Nested
    @DisplayName("generer")
    class Generer {

        private Candidature sirineAcceptee() {
            ProjetStage projet = projetMobile(LocalDate.of(2026, 6, 1));
            Candidature c = candidature(1L, "Sirine", projet, LICENCE,
                    LocalDate.of(2026, 5, 10), MOBILE, API_REST);
            c.setStatut(StatutCandidature.ACCEPTEE);
            return c;
        }

        @Test
        @DisplayName("Candidature acceptée → convention n°3 de juin 2026 liée à la candidature")
        void candidatureAcceptee() {
            Candidature sirine = sirineAcceptee();
            when(candidatureRepository.findById(1L)).thenReturn(Optional.of(sirine));
            when(conventionRepository.findByCandidatureId(1L)).thenReturn(Optional.empty());
            when(conventionRepository.findMaxNumSequentiel(6, 2026)).thenReturn(2);
            when(conventionRepository.save(any(ConventionStage.class))).thenAnswer(inv -> inv.getArgument(0));

            ConventionResponse reponse = service.generer(1L);

            ArgumentCaptor<ConventionStage> capture = ArgumentCaptor.forClass(ConventionStage.class);
            verify(conventionRepository).save(capture.capture());
            ConventionStage enregistree = capture.getValue();

            assertThat(enregistree.getNumSequentiel()).isEqualTo(3);
            assertThat(enregistree.getMois()).isEqualTo(6);
            assertThat(enregistree.getAnnee()).isEqualTo(2026);
            assertThat(enregistree.getDateCreation()).isEqualTo(LocalDate.now());
            assertThat(enregistree.getCandidature()).isSameAs(sirine);

            assertThat(reponse.stagiaire()).isEqualTo("Sirine");
            assertThat(reponse.mentorNom()).isEqualTo("Ahmed");
            assertThat(reponse.projetTitre()).isEqualTo("Développement d'une application mobile");
        }

        @Test
        @DisplayName("Candidature encore en attente → refusée, rien n'est enregistré")
        void candidatureEnAttente() {
            Candidature c = sirineAcceptee();
            c.setStatut(StatutCandidature.EN_ATTENTE);
            when(candidatureRepository.findById(1L)).thenReturn(Optional.of(c));

            assertThatThrownBy(() -> service.generer(1L))
                    .isInstanceOf(BusinessException.class)
                    .hasMessageContaining("acceptée");
            verify(conventionRepository, never()).save(any());
        }

        @Test
        @DisplayName("Une seule convention par candidature (multiplicité 0..1)")
        void conventionDejaExistante() {
            Candidature c = sirineAcceptee();
            when(candidatureRepository.findById(1L)).thenReturn(Optional.of(c));
            when(conventionRepository.findByCandidatureId(1L)).thenReturn(Optional.of(new ConventionStage()));

            assertThatThrownBy(() -> service.generer(1L))
                    .isInstanceOf(BusinessException.class)
                    .hasMessageContaining("existe déjà");
            verify(conventionRepository, never()).save(any());
        }

        @Test
        @DisplayName("Candidature introuvable → ResourceNotFoundException")
        void candidatureIntrouvable() {
            when(candidatureRepository.findById(99L)).thenReturn(Optional.empty());

            assertThatThrownBy(() -> service.generer(99L))
                    .isInstanceOf(ResourceNotFoundException.class);
        }
    }
}
