package com.devtec.gestionstages.service;

import com.devtec.gestionstages.dto.CompetencePoidsRequest;
import com.devtec.gestionstages.dto.CompetencePoidsResponse;
import com.devtec.gestionstages.dto.ProjetStageRequest;
import com.devtec.gestionstages.dto.ProjetStageResponse;
import com.devtec.gestionstages.dto.TacheResponse;
import com.devtec.gestionstages.entity.*;
import com.devtec.gestionstages.exception.BusinessException;
import com.devtec.gestionstages.exception.ResourceNotFoundException;
import com.devtec.gestionstages.repository.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;
import java.util.Set;

import static com.devtec.gestionstages.service.DonneesTest.*;
import static org.assertj.core.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
@DisplayName("ProjetStageService : module « gérer stages » (projets, tâches, compétences pondérées)")
class ProjetStageServiceTest {

    @Mock private ProjetStageRepository projetRepository;
    @Mock private MentorRepository mentorRepository;
    @Mock private NiveauEtudesRepository niveauRepository;
    @Mock private CompetenceRepository competenceRepository;
    @Mock private CandidatureRepository candidatureRepository;
    @InjectMocks private ProjetStageService service;

    private static final LocalDate DEBUT = LocalDate.of(2027, 2, 1);
    private static final LocalDate FIN = LocalDate.of(2027, 5, 31);

    private Mentor ahmed;

    @BeforeEach
    void preparer() {
        ahmed = mentor(1L, "Ahmed");
    }

    private ProjetStageRequest requete(LocalDate debut, LocalDate fin,
                                       List<CompetencePoidsRequest> competences, List<String> taches) {
        return new ProjetStageRequest("  Application mobile  ", debut, fin, "Objectifs",
                1L, Set.of(1L, 3L), competences, taches);
    }

    // ------------------------------------------------------------------ create

    @Nested
    @DisplayName("create")
    class Create {

        @Test
        @DisplayName("Projet valide → enregistré avec son mentor, ses niveaux, compétences pondérées et tâches")
        void projetValide() {
            when(mentorRepository.findById(1L)).thenReturn(Optional.of(ahmed));
            when(niveauRepository.findAllById(any())).thenReturn(List.of(LICENCE, INGENIEUR));
            when(projetRepository.save(any(ProjetStage.class))).thenAnswer(inv -> {
                ProjetStage p = inv.getArgument(0);
                p.setId(10L);                                   // id attribué par MySQL
                return p;
            });
            when(competenceRepository.findById(1L)).thenReturn(Optional.of(MOBILE));
            when(competenceRepository.findById(3L)).thenReturn(Optional.of(API_REST));

            ProjetStageResponse r = service.create(requete(DEBUT, FIN,
                    List.of(new CompetencePoidsRequest(1L, 3), new CompetencePoidsRequest(3L, 2)),
                    List.of("Créer des maquettes", " Développer le back-end ")));

            assertThat(r.id()).isEqualTo(10L);
            assertThat(r.titre()).isEqualTo("Application mobile");
            assertThat(r.mentorNom()).isEqualTo("Ahmed");
            assertThat(r.niveaux()).containsExactly("INGENIEUR", "LICENCE");
            assertThat(r.competences())
                    .extracting(CompetencePoidsResponse::competenceId, CompetencePoidsResponse::poids)
                    .containsExactlyInAnyOrder(tuple(1L, 3), tuple(3L, 2));
            assertThat(r.taches()).extracting(TacheResponse::libelle)
                    .containsExactly("Créer des maquettes", "Développer le back-end");
        }

        @Test
        @DisplayName("Date de fin avant la date de début → refusé, rien n'est enregistré")
        void datesIncoherentes() {
            assertThatThrownBy(() -> service.create(requete(FIN, DEBUT, List.of(), List.of())))
                    .isInstanceOf(BusinessException.class)
                    .hasMessageContaining("date de fin");
            verify(projetRepository, never()).save(any());
        }

        @Test
        @DisplayName("Date de fin égale à la date de début → refusé")
        void datesEgales() {
            assertThatThrownBy(() -> service.create(requete(DEBUT, DEBUT, List.of(), List.of())))
                    .isInstanceOf(BusinessException.class);
        }

        @Test
        @DisplayName("Mentor inexistant → ResourceNotFoundException (multiplicité 1)")
        void mentorIntrouvable() {
            when(mentorRepository.findById(1L)).thenReturn(Optional.empty());

            assertThatThrownBy(() -> service.create(requete(DEBUT, FIN, List.of(), List.of())))
                    .isInstanceOf(ResourceNotFoundException.class);
            verify(projetRepository, never()).save(any());
        }

        @Test
        @DisplayName("Niveau d'études inexistant → ResourceNotFoundException")
        void niveauIntrouvable() {
            when(mentorRepository.findById(1L)).thenReturn(Optional.of(ahmed));
            when(niveauRepository.findAllById(any())).thenReturn(List.of(LICENCE));     // 3 introuvable

            assertThatThrownBy(() -> service.create(requete(DEBUT, FIN, List.of(), List.of())))
                    .isInstanceOf(ResourceNotFoundException.class);
            verify(projetRepository, never()).save(any());
        }
    }

    // ------------------------------------------------------------------ update

    @Test
    @DisplayName("update : change un poids, retire et ajoute des compétences (classe d'association)")
    void updateCompetences() {
        ProjetStage existant = projetMobile(DEBUT);         // Mobile 3, UI/UX 2, API REST 2
        when(projetRepository.findById(1L)).thenReturn(Optional.of(existant));
        when(mentorRepository.findById(1L)).thenReturn(Optional.of(ahmed));
        when(niveauRepository.findAllById(any())).thenReturn(List.of(LICENCE, INGENIEUR));
        when(competenceRepository.findById(4L)).thenReturn(Optional.of(PYTHON));

        ProjetStageResponse r = service.update(1L, requete(DEBUT, FIN,
                List.of(new CompetencePoidsRequest(1L, 5),      // Mobile : 3 → 5
                        new CompetencePoidsRequest(4L, 1)),     // Python : ajoutée
                List.of("Nouvelle tâche")));                    // UI/UX et API REST : retirées

        assertThat(r.competences())
                .extracting(CompetencePoidsResponse::competenceId, CompetencePoidsResponse::poids)
                .containsExactlyInAnyOrder(tuple(1L, 5), tuple(4L, 1));
        assertThat(r.taches()).extracting(TacheResponse::libelle).containsExactly("Nouvelle tâche");
        verify(competenceRepository, never()).findById(1L);    // Mobile mise à jour, pas recréée
    }

    // ------------------------------------------------------------------ delete

    @Nested
    @DisplayName("delete")
    class Delete {

        @Test
        @DisplayName("Projet sans candidature → supprimé (les tâches suivent par composition)")
        void sansCandidature() {
            ProjetStage p = projetMobile(DEBUT);
            when(projetRepository.findById(1L)).thenReturn(Optional.of(p));
            when(candidatureRepository.findByProjetId(1L)).thenReturn(List.of());

            service.delete(1L);

            verify(projetRepository).delete(p);
        }

        @Test
        @DisplayName("Projet ayant reçu des candidatures → suppression refusée")
        void avecCandidatures() {
            ProjetStage p = projetMobile(DEBUT);
            when(projetRepository.findById(1L)).thenReturn(Optional.of(p));
            when(candidatureRepository.findByProjetId(1L))
                    .thenReturn(List.of(candidature(1L, "Sirine", p, LICENCE, LocalDate.now(), MOBILE)));

            assertThatThrownBy(() -> service.delete(1L))
                    .isInstanceOf(BusinessException.class)
                    .hasMessageContaining("candidatures");
            verify(projetRepository, never()).delete(any());
        }

        @Test
        @DisplayName("Projet inexistant → ResourceNotFoundException")
        void projetIntrouvable() {
            when(projetRepository.findById(99L)).thenReturn(Optional.empty());
            assertThatThrownBy(() -> service.delete(99L)).isInstanceOf(ResourceNotFoundException.class);
        }
    }

    // ------------------------------------------------------------------ tâches (composition)

    @Test
    @DisplayName("addTache : la tâche est rattachée au projet et son libellé est nettoyé")
    void ajouterTache() {
        ProjetStage p = projetMobile(DEBUT);                // contient déjà 1 tâche
        when(projetRepository.findById(1L)).thenReturn(Optional.of(p));

        TacheResponse r = service.addTache(1L, "  Rédiger le guide utilisateur ");

        assertThat(r.libelle()).isEqualTo("Rédiger le guide utilisateur");
        assertThat(p.getTaches()).hasSize(2);
        assertThat(p.getTaches().get(1).getProjet()).isSameAs(p);
        verify(projetRepository).saveAndFlush(p);
    }

    @Test
    @DisplayName("deleteTache : une tâche qui n'appartient pas au projet → ResourceNotFoundException")
    void supprimerTacheInconnue() {
        ProjetStage p = projetMobile(DEBUT);
        p.getTaches().get(0).setId(1L);
        when(projetRepository.findById(1L)).thenReturn(Optional.of(p));

        assertThatThrownBy(() -> service.deleteTache(1L, 42L))
                .isInstanceOf(ResourceNotFoundException.class);
        assertThat(p.getTaches()).hasSize(1);
    }

    @Test
    @DisplayName("deleteTache : la tâche est retirée du projet (orphanRemoval)")
    void supprimerTache() {
        ProjetStage p = projetMobile(DEBUT);
        Tache tache = p.getTaches().get(0);
        tache.setId(1L);
        when(projetRepository.findById(1L)).thenReturn(Optional.of(p));

        service.deleteTache(1L, 1L);

        assertThat(p.getTaches()).isEmpty();
        assertThat(tache.getProjet()).isNull();
    }

    // ------------------------------------------------------------------ appartientAuMentor

    @Test
    @DisplayName("appartientAuMentor : vrai pour Ahmed, faux pour un autre mentor")
    void appartientAuMentor() {
        when(projetRepository.findById(1L)).thenReturn(Optional.of(projetMobile(DEBUT)));

        assertThat(service.appartientAuMentor(1L, 1L)).isTrue();
        assertThat(service.appartientAuMentor(1L, 2L)).isFalse();
    }
}
