package com.devtec.gestionstages.service;

import com.devtec.gestionstages.dto.CandidatureRequest;
import com.devtec.gestionstages.dto.CandidatureResponse;
import com.devtec.gestionstages.entity.*;
import com.devtec.gestionstages.exception.BusinessException;
import com.devtec.gestionstages.exception.ResourceNotFoundException;
import com.devtec.gestionstages.repository.CandidatureRepository;
import com.devtec.gestionstages.repository.CompetenceRepository;
import com.devtec.gestionstages.repository.NiveauEtudesRepository;
import com.devtec.gestionstages.repository.ProjetStageRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;
import java.util.Set;

import static com.devtec.gestionstages.service.DonneesTest.*;
import static org.assertj.core.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
@DisplayName("CandidatureService : soumission, /score et tri automatique")
class CandidatureServiceTest {

    @Mock private CandidatureRepository candidatureRepository;
    @Mock private ProjetStageRepository projetRepository;
    @Mock private NiveauEtudesRepository niveauRepository;
    @Mock private CompetenceRepository competenceRepository;
    @InjectMocks private CandidatureService service;

    private ProjetStage projet;

    @BeforeEach
    void preparer() {
        projet = projetMobile(LocalDate.of(2026, 6, 1));
    }

    // ------------------------------------------------------------------ calculerScore (/score)

    @Nested
    @DisplayName("calculerScore : 30 pts niveau + 70 pts compétences pondérées")
    class CalculerScore {

        @Test
        @DisplayName("Niveau souhaité + toutes les compétences → 100")
        void candidatParfait() {
            Candidature c = candidature(1L, "Parfait", projet, INGENIEUR, LocalDate.now(),
                    MOBILE, UI_UX, API_REST);
            assertThat(service.calculerScore(c)).isEqualTo(100.0);
        }

        @Test
        @DisplayName("Sirine : Licence + Mobile (3) + API REST (2) → 30 + 70 × 5/7 = 80")
        void sirine() {
            Candidature c = candidature(1L, "Sirine", projet, LICENCE, LocalDate.now(), MOBILE, API_REST);
            assertThat(service.calculerScore(c)).isEqualTo(80.0);
        }

        @Test
        @DisplayName("Youssef : Mastère (non souhaité) + Python (non requise) → 0")
        void youssef() {
            Candidature c = candidature(2L, "Youssef", projet, MASTERE, LocalDate.now(), PYTHON);
            assertThat(service.calculerScore(c)).isZero();
        }

        @Test
        @DisplayName("Bon niveau mais aucune compétence requise → 30")
        void niveauSeulement() {
            Candidature c = candidature(3L, "Amine", projet, INGENIEUR, LocalDate.now(), PYTHON);
            assertThat(service.calculerScore(c)).isEqualTo(30.0);
        }

        @Test
        @DisplayName("Mauvais niveau mais toutes les compétences → 70")
        void competencesSeulement() {
            Candidature c = candidature(4L, "Lina", projet, MASTERE, LocalDate.now(),
                    MOBILE, UI_UX, API_REST);
            assertThat(service.calculerScore(c)).isEqualTo(70.0);
        }

        @Test
        @DisplayName("Projet sans compétence requise : les 70 points sont acquis")
        void projetSansCompetence() {
            projet.getCompetences().clear();
            Candidature c = candidature(5L, "Omar", projet, LICENCE, LocalDate.now(), PYTHON);
            assertThat(service.calculerScore(c)).isEqualTo(100.0);
        }

        @Test
        @DisplayName("Le score est arrondi à 0,1 près (70 × 1/3 = 23,3)")
        void arrondi() {
            projet.getCompetences().clear();
            projet.ajouterCompetence(MOBILE, 1);
            projet.ajouterCompetence(UI_UX, 1);
            projet.ajouterCompetence(API_REST, 1);
            Candidature c = candidature(6L, "Rim", projet, MASTERE, LocalDate.now(), MOBILE);
            assertThat(service.calculerScore(c)).isEqualTo(23.3);
        }
    }

    // ------------------------------------------------------------------ trier

    @Test
    @DisplayName("trier : score décroissant, puis premier arrivé en cas d'égalité")
    void trier() {
        Candidature youssef = candidature(2L, "Youssef", projet, MASTERE, LocalDate.of(2026, 5, 12), PYTHON);
        Candidature sirine = candidature(1L, "Sirine", projet, LICENCE, LocalDate.of(2026, 5, 10), MOBILE, API_REST);
        Candidature tardif = candidature(3L, "Tardif", projet, LICENCE, LocalDate.of(2026, 5, 20), MOBILE, API_REST);
        Candidature parfait = candidature(4L, "Parfait", projet, INGENIEUR, LocalDate.of(2026, 5, 25),
                MOBILE, UI_UX, API_REST);

        List<Candidature> classement = service.trier(List.of(youssef, tardif, parfait, sirine));

        assertThat(classement).extracting(Candidature::getNomCandidat)
                .containsExactly("Parfait", "Sirine", "Tardif", "Youssef");
        assertThat(classement).extracting(Candidature::getScore)
                .containsExactly(100.0, 80.0, 80.0, 0.0);
    }

    // ------------------------------------------------------------------ soumettre

    @Nested
    @DisplayName("soumettre (cas « soumettre candidature »)")
    class Soumettre {

        private ProjetStage projetAVenir;

        @BeforeEach
        void preparer() {
            projetAVenir = projetMobile(LocalDate.now().plusMonths(2));
        }

        private CandidatureRequest requete(String email, Set<Long> competences) {
            return new CandidatureRequest("  Sirine  ", email, 1L, 1L, competences);
        }

        @Test
        @DisplayName("Candidature valide → enregistrée EN_ATTENTE, email normalisé, score calculé")
        void candidatureValide() {
            when(projetRepository.findById(1L)).thenReturn(Optional.of(projetAVenir));
            when(candidatureRepository.existsByEmailAndProjetId("sirine@mail.com", 1L)).thenReturn(false);
            when(niveauRepository.findById(1L)).thenReturn(Optional.of(LICENCE));
            when(competenceRepository.findAllById(any())).thenReturn(List.of(MOBILE, API_REST));
            when(candidatureRepository.save(any(Candidature.class))).thenAnswer(inv -> inv.getArgument(0));

            CandidatureResponse r = service.soumettre(requete(" Sirine@Mail.com ", Set.of(1L, 3L)));

            assertThat(r.nomCandidat()).isEqualTo("Sirine");
            assertThat(r.email()).isEqualTo("sirine@mail.com");
            assertThat(r.statut()).isEqualTo(StatutCandidature.EN_ATTENTE);
            assertThat(r.dateCandidature()).isEqualTo(LocalDate.now());
            assertThat(r.score()).isEqualTo(80.0);
            verify(candidatureRepository).save(any(Candidature.class));
        }

        @Test
        @DisplayName("Projet déjà commencé → candidatures closes")
        void projetCommence() {
            when(projetRepository.findById(1L)).thenReturn(Optional.of(projet));   // juin 2026, passé

            assertThatThrownBy(() -> service.soumettre(requete("sirine@mail.com", Set.of(1L))))
                    .isInstanceOf(BusinessException.class)
                    .hasMessageContaining("closes");
            verify(candidatureRepository, never()).save(any());
        }

        @Test
        @DisplayName("Même email sur le même projet → refusée")
        void dejaPostule() {
            when(projetRepository.findById(1L)).thenReturn(Optional.of(projetAVenir));
            when(candidatureRepository.existsByEmailAndProjetId("sirine@mail.com", 1L)).thenReturn(true);

            assertThatThrownBy(() -> service.soumettre(requete("sirine@mail.com", Set.of(1L))))
                    .isInstanceOf(BusinessException.class)
                    .hasMessageContaining("déjà postulé");
            verify(candidatureRepository, never()).save(any());
        }

        @Test
        @DisplayName("Compétence inexistante → ResourceNotFoundException")
        void competenceInconnue() {
            when(projetRepository.findById(1L)).thenReturn(Optional.of(projetAVenir));
            when(candidatureRepository.existsByEmailAndProjetId("sirine@mail.com", 1L)).thenReturn(false);
            when(niveauRepository.findById(1L)).thenReturn(Optional.of(LICENCE));
            when(competenceRepository.findAllById(any())).thenReturn(List.of(MOBILE));  // 99 introuvable

            assertThatThrownBy(() -> service.soumettre(requete("sirine@mail.com", Set.of(1L, 99L))))
                    .isInstanceOf(ResourceNotFoundException.class);
            verify(candidatureRepository, never()).save(any());
        }

        @Test
        @DisplayName("Projet inexistant → ResourceNotFoundException")
        void projetInconnu() {
            when(projetRepository.findById(1L)).thenReturn(Optional.empty());

            assertThatThrownBy(() -> service.soumettre(requete("sirine@mail.com", Set.of(1L))))
                    .isInstanceOf(ResourceNotFoundException.class);
        }
    }

    // ------------------------------------------------------------------ accepter / refuser

    @Test
    @DisplayName("accepter : EN_ATTENTE → ACCEPTEE")
    void accepter() {
        Candidature c = candidature(1L, "Sirine", projet, LICENCE, LocalDate.now(), MOBILE);
        when(candidatureRepository.findById(1L)).thenReturn(Optional.of(c));

        CandidatureResponse r = service.accepter(1L);

        assertThat(r.statut()).isEqualTo(StatutCandidature.ACCEPTEE);
        assertThat(c.getStatut()).isEqualTo(StatutCandidature.ACCEPTEE);
    }

    @Test
    @DisplayName("refuser une candidature déjà acceptée → interdit")
    void refuserCandidatureDejaTraitee() {
        Candidature c = candidature(1L, "Sirine", projet, LICENCE, LocalDate.now(), MOBILE);
        c.setStatut(StatutCandidature.ACCEPTEE);
        when(candidatureRepository.findById(1L)).thenReturn(Optional.of(c));

        assertThatThrownBy(() -> service.refuser(1L))
                .isInstanceOf(BusinessException.class)
                .hasMessageContaining("déjà été traitée");
        assertThat(c.getStatut()).isEqualTo(StatutCandidature.ACCEPTEE);
    }
}
