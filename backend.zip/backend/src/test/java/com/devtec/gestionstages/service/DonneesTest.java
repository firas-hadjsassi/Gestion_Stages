package com.devtec.gestionstages.service;

import com.devtec.gestionstages.entity.*;

import java.time.LocalDate;
import java.util.Set;

/**
 * Jeu de données commun aux tests unitaires, inspiré de l'Annexe 1 :
 * projet « application mobile » encadré par Ahmed,
 * niveaux souhaités LICENCE et INGENIEUR,
 * compétences requises Mobile (poids 3), UI/UX (poids 2), API REST (poids 2) → total 7.
 */
final class DonneesTest {

    private DonneesTest() {}

    static final NiveauEtudes LICENCE = niveau(1L, "LICENCE");
    static final NiveauEtudes MASTERE = niveau(2L, "MASTERE");
    static final NiveauEtudes INGENIEUR = niveau(3L, "INGENIEUR");

    static final Competence MOBILE = competence(1L, "Développement mobile (Android/iOS)");
    static final Competence UI_UX = competence(2L, "Design UI/UX");
    static final Competence API_REST = competence(3L, "API REST");
    static final Competence PYTHON = competence(4L, "Python");

    static NiveauEtudes niveau(Long id, String libelle) {
        NiveauEtudes n = new NiveauEtudes(libelle);
        n.setId(id);
        return n;
    }

    static Competence competence(Long id, String libelle) {
        Competence c = new Competence(libelle);
        c.setId(id);
        return c;
    }

    static Mentor mentor(Long id, String nom) {
        Mentor m = new Mentor();
        m.setId(id);
        m.setNom(nom);
        m.setSpecialite("Développement mobile");
        m.setCompte(new Compte(nom.toLowerCase(), "x", Role.MENTOR));
        return m;
    }

    /** Projet de l'Annexe 1, qui commence à la date indiquée. */
    static ProjetStage projetMobile(LocalDate dateDebut) {
        ProjetStage p = new ProjetStage();
        p.setId(1L);
        p.setTitre("Développement d'une application mobile");
        p.setDateDebut(dateDebut);
        p.setDateFin(dateDebut.plusMonths(4));
        p.setObjectifs("Créer une application mobile conviviale");
        p.setMentor(mentor(1L, "Ahmed"));
        p.getNiveauxSouhaites().addAll(Set.of(LICENCE, INGENIEUR));
        p.ajouterCompetence(MOBILE, 3);
        p.ajouterCompetence(UI_UX, 2);
        p.ajouterCompetence(API_REST, 2);
        p.ajouterTache(new Tache("Conception de l'interface utilisateur"));
        return p;
    }

    static Candidature candidature(Long id, String nom, ProjetStage projet, NiveauEtudes niveau,
                                   LocalDate date, Competence... competences) {
        Candidature c = new Candidature();
        c.setId(id);
        c.setNomCandidat(nom);
        c.setEmail(nom.toLowerCase() + "@mail.com");
        c.setDateCandidature(date);
        c.setStatut(StatutCandidature.EN_ATTENTE);
        c.setProjet(projet);
        c.setNiveau(niveau);
        c.getCompetences().addAll(Set.of(competences));
        return c;
    }
}
