package com.devtec.gestionstages.security.jwt;

import com.devtec.gestionstages.security.UtilisateurConnecte;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;
import lombok.RequiredArgsConstructor;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

/**
 * Lit l'en-tête "Authorization: Bearer <token>" de chaque requête.
 * Si le token est valide, l'utilisateur est authentifié avec le rôle ROLE_RH, ROLE_MENTOR ou ROLE_ADMIN.
 */
@Component
@RequiredArgsConstructor
public class JwtAuthFilter extends OncePerRequestFilter {

    private final JwtService jwtService;

    @Override
    protected void doFilterInternal(HttpServletRequest request,
                                    HttpServletResponse response,
                                    FilterChain chain) throws ServletException, IOException {
        String entete = request.getHeader("Authorization");

        if (entete != null && entete.startsWith("Bearer ")) {
            UtilisateurConnecte utilisateur = jwtService.lireToken(entete.substring(7));
            if (utilisateur != null) {
                UsernamePasswordAuthenticationToken authentification = new UsernamePasswordAuthenticationToken(
                        utilisateur,
                        null,
                        List.of(new SimpleGrantedAuthority("ROLE_" + utilisateur.role().name())));
                SecurityContextHolder.getContext().setAuthentication(authentification);
            }
        }
        chain.doFilter(request, response);
    }
}