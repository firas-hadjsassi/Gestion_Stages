package com.devtec.gestionstages.entity;

import jakarta.persistence.*;
import lombok.*;

/** Classe Tâche, partie de ProjetStage (composition ◆ 0..*) → table tache. */
@Entity
@Table(name = "tache")
@Getter
@Setter
@NoArgsConstructor
public class Tache {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, length = 200)
    private String libelle;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "projet_id", nullable = false)
    private ProjetStage projet;

    public Tache(String libelle) {
        this.libelle = libelle;
    }
}