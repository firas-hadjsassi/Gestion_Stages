package com.devtec.gestionstages.entity;

import jakarta.persistence.*;
import lombok.*;

/** Classe NiveauEtudes (LICENCE, MASTERE, INGENIEUR) → table niveau_etudes. */
@Entity
@Table(name = "niveau_etudes")
@Getter
@Setter
@NoArgsConstructor
public class NiveauEtudes {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, unique = true, length = 50)
    private String niveau;

    public NiveauEtudes(String niveau) {
        this.niveau = niveau;
    }
}