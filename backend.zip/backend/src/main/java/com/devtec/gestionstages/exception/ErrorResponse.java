package com.devtec.gestionstages.exception;

import java.time.LocalDateTime;
import java.util.Map;

/** Format JSON de toutes les erreurs renvoyées à React. */
public record ErrorResponse(
        LocalDateTime timestamp,
        int status,
        String message,
        Map<String, String> erreurs
) {
    public static ErrorResponse of(int status, String message) {
        return new ErrorResponse(LocalDateTime.now(), status, message, Map.of());
    }

    public static ErrorResponse of(int status, String message, Map<String, String> erreurs) {
        return new ErrorResponse(LocalDateTime.now(), status, message, erreurs);
    }
}