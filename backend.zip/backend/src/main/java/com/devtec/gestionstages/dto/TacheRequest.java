package com.devtec.gestionstages.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

public record TacheRequest(

        @NotBlank(message = "Le libellé de la tâche est obligatoire")
        @Size(max = 200)
        String libelle
) {}