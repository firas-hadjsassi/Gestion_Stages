package com.devtec.gestionstages.entity;

import jakarta.persistence.*;
import lombok.*;

/** Classe Compétence (libellé) → table competence. */
@Entity
@Table(name = "competence")
@Getter
@Setter
@NoArgsConstructor
public class Competence {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, unique = true, length = 100)
    private String libelle;

    public Competence(String libelle) {
        this.libelle = libelle;
    }
}