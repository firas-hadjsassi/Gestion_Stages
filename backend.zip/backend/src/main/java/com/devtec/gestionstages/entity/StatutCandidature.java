package com.devtec.gestionstages.entity;

public enum StatutCandidature {
    EN_ATTENTE, ACCEPTEE, REFUSEE
}