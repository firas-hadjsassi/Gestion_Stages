package com.devtec.gestionstages.repository;

import com.devtec.gestionstages.entity.CompetenceProjet;
import com.devtec.gestionstages.entity.CompetenceProjetId;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

/** Classe d'association : la clé est la clé composée CompetenceProjetId. */
public interface CompetenceProjetRepository extends JpaRepository<CompetenceProjet, CompetenceProjetId> {

    List<CompetenceProjet> findByProjetId(Long projetId);
}