package com.devtec.gestionstages.entity;

import jakarta.persistence.*;
import lombok.*;

/** Classe d'association CompetenceProjet (poids) entre Compétence et ProjetStage → table competence_projet. */
@Entity
@Table(name = "competence_projet")
@Getter
@Setter
@NoArgsConstructor
public class CompetenceProjet {

    @EmbeddedId
    private CompetenceProjetId id = new CompetenceProjetId();

    @ManyToOne(fetch = FetchType.LAZY)
    @MapsId("competenceId")
    @JoinColumn(name = "competence_id")
    private Competence competence;

    @ManyToOne(fetch = FetchType.LAZY)
    @MapsId("projetId")
    @JoinColumn(name = "projet_id")
    private ProjetStage projet;

    @Column(nullable = false)
    private int poids = 1;

    public CompetenceProjet(Competence competence, ProjetStage projet, int poids) {
        this.competence = competence;
        this.projet = projet;
        this.poids = poids;
        this.id = new CompetenceProjetId(competence.getId(), projet.getId());
    }
}