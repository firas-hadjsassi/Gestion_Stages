package com.devtec.gestionstages.service;

import com.devtec.gestionstages.dto.CompteRequest;
import com.devtec.gestionstages.dto.CompteResponse;
import com.devtec.gestionstages.entity.AgentRH;
import com.devtec.gestionstages.entity.Compte;
import com.devtec.gestionstages.entity.Mentor;
import com.devtec.gestionstages.entity.Role;
import com.devtec.gestionstages.exception.BusinessException;
import com.devtec.gestionstages.exception.ResourceNotFoundException;
import com.devtec.gestionstages.repository.AgentRHRepository;
import com.devtec.gestionstages.repository.CompteRepository;
import com.devtec.gestionstages.repository.MentorRepository;
import com.devtec.gestionstages.repository.ProjetStageRepository;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import lombok.RequiredArgsConstructor;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * Cas « gérer comptes » (administrateur).
 * Contrainte {XOR} : un compte RH est lié à un AgentRH, un compte MENTOR à un Mentor,
 * jamais aux deux. Un compte ADMIN n'est lié à aucun des deux.
 */
@Service
@RequiredArgsConstructor
@Transactional
public class CompteService {

    private final CompteRepository compteRepository;
    private final AgentRHRepository agentRHRepository;
    private final MentorRepository mentorRepository;
    private final ProjetStageRepository projetRepository;
    private final PasswordEncoder passwordEncoder;

    @Transactional(readOnly = true)
    public List<CompteResponse> findAll() {
        return compteRepository.findAll().stream()
                .sorted(Comparator.comparing(Compte::getRole).thenComparing(Compte::getLogin))
                .map(this::toResponse)
                .toList();
    }

    public CompteResponse create(CompteRequest req) {
        String login = req.login().trim();
        if (compteRepository.existsByLogin(login)) {
            throw new BusinessException("Le login « " + login + " » est déjà utilisé");
        }
        if (req.role() != Role.ADMIN && (req.nom() == null || req.nom().isBlank())) {
            throw new BusinessException("Le nom est obligatoire pour un compte " + req.role());
        }

        Compte compte = new Compte(login, passwordEncoder.encode(req.mdp()), req.role());

        switch (req.role()) {
            case RH -> {
                AgentRH agent = new AgentRH();
                agent.setNom(req.nom().trim());
                agent.setCompte(compte);
                agentRHRepository.save(agent);           // cascade : le compte est créé aussi
            }
            case MENTOR -> {
                Mentor mentor = new Mentor();
                mentor.setNom(req.nom().trim());
                mentor.setSpecialite(req.specialite());
                mentor.setCompte(compte);
                mentorRepository.save(mentor);
            }
            case ADMIN -> compteRepository.save(compte);
        }
        return toResponse(compte);
    }

    public void changerMotDePasse(Long id, String mdp) {
        Compte compte = getCompte(id);
        compte.setMdp(passwordEncoder.encode(mdp));
    }

    public void delete(Long id) {
        Compte compte = getCompte(id);

        Optional<Mentor> mentor = mentorRepository.findByCompteId(id);
        if (mentor.isPresent()) {
            if (!projetRepository.findByMentorId(mentor.get().getId()).isEmpty()) {
                throw new BusinessException("Impossible de supprimer ce compte : le mentor encadre encore des projets");
            }
            mentorRepository.delete(mentor.get());       // supprime aussi le compte (cascade)
            return;
        }

        Optional<AgentRH> agent = agentRHRepository.findByCompteId(id);
        if (agent.isPresent()) {
            agentRHRepository.delete(agent.get());
            return;
        }

        if (compte.getRole() == Role.ADMIN
                && compteRepository.findAll().stream().filter(c -> c.getRole() == Role.ADMIN).count() <= 1) {
            throw new BusinessException("Impossible de supprimer le dernier compte administrateur");
        }
        compteRepository.delete(compte);
    }

    // ------------------------------------------------------------------ Utilitaires

    /** Nom affiché : celui de l'agent RH ou du mentor lié au compte (null pour ADMIN). */
    public String nomDuCompte(Compte compte) {
        return switch (compte.getRole()) {
            case RH -> agentRHRepository.findByCompteId(compte.getId()).map(AgentRH::getNom).orElse(null);
            case MENTOR -> mentorRepository.findByCompteId(compte.getId()).map(Mentor::getNom).orElse(null);
            case ADMIN -> null;
        };
    }

    private CompteResponse toResponse(Compte compte) {
        return new CompteResponse(compte.getId(), compte.getLogin(), compte.getRole(), nomDuCompte(compte));
    }

    private Compte getCompte(Long id) {
        return compteRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Compte", id));
    }
}