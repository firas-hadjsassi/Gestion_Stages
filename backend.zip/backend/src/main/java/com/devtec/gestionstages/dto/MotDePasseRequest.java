package com.devtec.gestionstages.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

/** Nouveau mot de passe (réinitialisation par l'administrateur). */
public record MotDePasseRequest(

        @NotBlank(message = "Le mot de passe est obligatoire")
        @Size(min = 4, message = "Le mot de passe doit contenir au moins 4 caractères")
        String mdp
) {}