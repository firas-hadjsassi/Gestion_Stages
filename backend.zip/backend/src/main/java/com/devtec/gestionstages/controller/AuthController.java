package com.devtec.gestionstages.controller;

import com.devtec.gestionstages.dto.LoginRequest;
import com.devtec.gestionstages.dto.LoginResponse;
import com.devtec.gestionstages.service.AuthService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/** Cas « s'authentifier » : POST /api/auth/login → { token, login, role, nom, profilId }. */
@RestController
@RequestMapping("/api/auth")
@RequiredArgsConstructor
public class AuthController {

    private final AuthService authService;

    @PostMapping("/login")
    public LoginResponse login(@Valid @RequestBody LoginRequest request) {
        return authService.login(request);
    }
}