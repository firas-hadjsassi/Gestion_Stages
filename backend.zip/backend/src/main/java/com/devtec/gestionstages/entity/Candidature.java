package com.devtec.gestionstages.entity;

import jakarta.persistence.*;
import java.time.LocalDate;
import java.util.*;
import lombok.*;

/**
 * Classe Candidature (nomCandidate, email, dateCandidature, statut, /score) → table candidature.
 *  - Candidature 0..* ---- 1 ProjetStage
 *  - Candidature 0..* ---- 1 NiveauEtudes
 *  - Candidature 0..* ---- 1..* Compétence (compétences du candidat)
 *  - /score : attribut dérivé, non stocké (calculé par le service)
 */
@Entity
@Table(name = "candidature")
@Getter
@Setter
@NoArgsConstructor
public class Candidature {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "nom_candidat", nullable = false, length = 100)
    private String nomCandidat;

    @Column(nullable = false, length = 150)
    private String email;

    @Column(name = "date_candidature", nullable = false)
    private LocalDate dateCandidature;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, columnDefinition = "ENUM('EN_ATTENTE','ACCEPTEE','REFUSEE')")
    private StatutCandidature statut = StatutCandidature.EN_ATTENTE;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "projet_id", nullable = false)
    private ProjetStage projet;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "niveau_id", nullable = false)
    private NiveauEtudes niveau;

    @ManyToMany
    @JoinTable(name = "candidature_competence",
               joinColumns = @JoinColumn(name = "candidature_id"),
               inverseJoinColumns = @JoinColumn(name = "competence_id"))
    private Set<Competence> competences = new HashSet<>();

    /** Attribut dérivé /score : jamais enregistré en base. */
    @Transient
    private double score;
}