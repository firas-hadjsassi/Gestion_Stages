package com.devtec.gestionstages.service;

import com.devtec.gestionstages.dto.CompetencePoidsRequest;
import com.devtec.gestionstages.dto.ProjetStageRequest;
import com.devtec.gestionstages.dto.ProjetStageResponse;
import com.devtec.gestionstages.dto.TacheResponse;
import com.devtec.gestionstages.entity.Competence;
import com.devtec.gestionstages.entity.CompetenceProjet;
import com.devtec.gestionstages.entity.Mentor;
import com.devtec.gestionstages.entity.NiveauEtudes;
import com.devtec.gestionstages.entity.ProjetStage;
import com.devtec.gestionstages.entity.Tache;
import com.devtec.gestionstages.exception.BusinessException;
import com.devtec.gestionstages.exception.ResourceNotFoundException;
import com.devtec.gestionstages.repository.CandidatureRepository;
import com.devtec.gestionstages.repository.CompetenceRepository;
import com.devtec.gestionstages.repository.MentorRepository;
import com.devtec.gestionstages.repository.NiveauEtudesRepository;
import com.devtec.gestionstages.repository.ProjetStageRepository;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/** Module « gérer stages » : projets de stage, tâches, compétences pondérées, niveaux souhaités. */
@Service
@RequiredArgsConstructor
@Transactional
public class ProjetStageService {

    private final ProjetStageRepository projetRepository;
    private final MentorRepository mentorRepository;
    private final NiveauEtudesRepository niveauRepository;
    private final CompetenceRepository competenceRepository;
    private final CandidatureRepository candidatureRepository;

    // ------------------------------------------------------------------ Lecture

    @Transactional(readOnly = true)
    public List<ProjetStageResponse> findAll() {
        return projetRepository.findAll().stream()
                .sorted(Comparator.comparing(ProjetStage::getDateDebut))
                .map(ProjetStageResponse::from)
                .toList();
    }

    @Transactional(readOnly = true)
    public ProjetStageResponse findById(Long id) {
        return ProjetStageResponse.from(getProjet(id));
    }

    @Transactional(readOnly = true)
    public List<ProjetStageResponse> findByMentor(Long mentorId) {
        return projetRepository.findByMentorId(mentorId).stream()
                .sorted(Comparator.comparing(ProjetStage::getDateDebut))
                .map(ProjetStageResponse::from)
                .toList();
    }

    // ------------------------------------------------------------------ Écriture

    public ProjetStageResponse create(ProjetStageRequest req) {
        ProjetStage projet = new ProjetStage();
        appliquerChamps(projet, req);
        projet = projetRepository.save(projet);          // l'id est attribué ici
        synchroniserCompetences(projet, req.competences());
        return ProjetStageResponse.from(projet);
    }

    public ProjetStageResponse update(Long id, ProjetStageRequest req) {
        ProjetStage projet = getProjet(id);
        appliquerChamps(projet, req);
        synchroniserCompetences(projet, req.competences());
        return ProjetStageResponse.from(projet);
    }

    public void delete(Long id) {
        ProjetStage projet = getProjet(id);
        if (!candidatureRepository.findByProjetId(id).isEmpty()) {
            throw new BusinessException("Impossible de supprimer ce projet : il a déjà reçu des candidatures");
        }
        projetRepository.delete(projet);                 // composition : les tâches sont supprimées aussi
    }

    public TacheResponse addTache(Long projetId, String libelle) {
        ProjetStage projet = getProjet(projetId);
        Tache tache = new Tache(libelle.trim());
        projet.ajouterTache(tache);
        projetRepository.saveAndFlush(projet);
        return TacheResponse.from(tache);
    }

    public void deleteTache(Long projetId, Long tacheId) {
        ProjetStage projet = getProjet(projetId);
        Tache tache = projet.getTaches().stream()
                .filter(t -> t.getId().equals(tacheId))
                .findFirst()
                .orElseThrow(() -> new ResourceNotFoundException("Tâche", tacheId));
        projet.retirerTache(tache);                      // orphanRemoval : supprimée en base
    }

    // ------------------------------------------------------------------ Utilitaires

    /** Renvoie le projet ou lève une exception 404. */
    public ProjetStage getProjet(Long id) {
        return projetRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Projet", id));
    }

    /** Vérifie que le projet appartient bien au mentor (utilisé par le contrôleur sécurisé). */
    @Transactional(readOnly = true)
    public boolean appartientAuMentor(Long projetId, Long mentorId) {
        return getProjet(projetId).getMentor().getId().equals(mentorId);
    }

    private void appliquerChamps(ProjetStage projet, ProjetStageRequest req) {
        if (!req.dateFin().isAfter(req.dateDebut())) {
            throw new BusinessException("La date de fin doit être postérieure à la date de début");
        }

        Mentor mentor = mentorRepository.findById(req.mentorId())
                .orElseThrow(() -> new ResourceNotFoundException("Mentor", req.mentorId()));

        List<NiveauEtudes> niveaux = niveauRepository.findAllById(req.niveauIds());
        if (niveaux.size() != req.niveauIds().size()) {
            throw new ResourceNotFoundException("Un des niveaux d'études est introuvable");
        }

        projet.setTitre(req.titre().trim());
        projet.setDateDebut(req.dateDebut());
        projet.setDateFin(req.dateFin());
        projet.setObjectifs(req.objectifs());
        projet.setMentor(mentor);

        projet.getNiveauxSouhaites().clear();
        projet.getNiveauxSouhaites().addAll(niveaux);

        // Tâches : la liste reçue remplace l'ancienne (composition)
        projet.getTaches().clear();
        if (req.taches() != null) {
            req.taches().forEach(libelle -> projet.ajouterTache(new Tache(libelle.trim())));
        }
    }

    /**
     * Met à jour la classe d'association CompetenceProjet sans tout supprimer/recréer
     * (évite un conflit de clé primaire composée dans la même transaction).
     */
    private void synchroniserCompetences(ProjetStage projet, List<CompetencePoidsRequest> demandes) {
        Map<Long, Integer> voulues = new LinkedHashMap<>();
        if (demandes != null) {
            demandes.forEach(d -> voulues.put(d.competenceId(), d.poids()));
        }

        // 1. supprimer celles qui ne sont plus demandées
        projet.getCompetences().removeIf(cp -> !voulues.containsKey(cp.getCompetence().getId()));

        // 2. mettre à jour le poids de celles qui restent
        for (CompetenceProjet cp : projet.getCompetences()) {
            cp.setPoids(voulues.remove(cp.getCompetence().getId()));
        }

        // 3. ajouter les nouvelles
        voulues.forEach((competenceId, poids) -> {
            Competence competence = competenceRepository.findById(competenceId)
                    .orElseThrow(() -> new ResourceNotFoundException("Compétence", competenceId));
            projet.ajouterCompetence(competence, poids);
        });
    }
}