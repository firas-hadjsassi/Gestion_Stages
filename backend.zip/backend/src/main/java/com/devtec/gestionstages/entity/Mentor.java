package com.devtec.gestionstages.entity;

import jakarta.persistence.*;
import lombok.*;

/** Mentor 0..1 ---- 1 Compte ; Mentor 1 ---- 0..* ProjetStage → table mentor. */
@Entity
@Table(name = "mentor")
@Getter
@Setter
@NoArgsConstructor
public class Mentor {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, length = 100)
    private String nom;

    @Column(length = 100)
    private String specialite;

    /** Le compte est créé et supprimé avec le mentor. */
    @OneToOne(optional = false, cascade = CascadeType.ALL)
    @JoinColumn(name = "compte_id", nullable = false, unique = true)
    private Compte compte;
}