package com.devtec.gestionstages.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

/** Création / modification d'un mentor par le service RH (avec son compte). */
public record MentorRequest(

        @NotBlank(message = "Le nom est obligatoire")
        @Size(max = 100)
        String nom,

        @Size(max = 100)
        String specialite,

        @NotBlank(message = "Le login est obligatoire")
        @Size(max = 50)
        String login,

        /** Obligatoire à la création, facultatif en modification (vide = inchangé). */
        String mdp
) {}