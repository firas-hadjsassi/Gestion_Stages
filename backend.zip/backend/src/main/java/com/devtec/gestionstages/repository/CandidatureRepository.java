package com.devtec.gestionstages.repository;

import com.devtec.gestionstages.entity.Candidature;
import com.devtec.gestionstages.entity.StatutCandidature;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface CandidatureRepository extends JpaRepository<Candidature, Long> {

    List<Candidature> findByProjetId(Long projetId);

    List<Candidature> findByStatut(StatutCandidature statut);

    /** Contrainte UNIQUE (email, projet_id) du script SQL : une seule candidature par projet. */
    boolean existsByEmailAndProjetId(String email, Long projetId);
}