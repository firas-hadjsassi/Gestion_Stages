package com.devtec.gestionstages.exception;

/** Élément introuvable en base → HTTP 404. */
public class ResourceNotFoundException extends RuntimeException {

    public ResourceNotFoundException(String message) {
        super(message);
    }

    public ResourceNotFoundException(String entite, Long id) {
        super(entite + " introuvable (id = " + id + ")");
    }
}