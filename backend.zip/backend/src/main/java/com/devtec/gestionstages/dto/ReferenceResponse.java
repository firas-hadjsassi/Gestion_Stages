package com.devtec.gestionstages.dto;

/** Élément simple (id + libellé) pour les listes déroulantes : compétences, niveaux. */
public record ReferenceResponse(Long id, String libelle) {}