package com.devtec.gestionstages.controller;

import com.devtec.gestionstages.dto.ConventionResponse;
import com.devtec.gestionstages.service.ConventionStageService;
import java.util.List;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

/**
 * Cas « gérer conventions » (Service RH).
 *   GET  /api/conventions                              lister
 *   GET  /api/conventions/{id}                         consulter / imprimer
 *   POST /api/conventions/candidature/{candidatureId}  générer (numéro NN-M-AAAA)
 */
@RestController
@RequestMapping("/api/conventions")
@RequiredArgsConstructor
public class ConventionStageController {

    private final ConventionStageService conventionService;

    @GetMapping
    public List<ConventionResponse> findAll() {
        return conventionService.findAll();
    }

    @GetMapping("/{id}")
    public ConventionResponse findById(@PathVariable Long id) {
        return conventionService.findById(id);
    }

    @PostMapping("/candidature/{candidatureId}")
    @ResponseStatus(HttpStatus.CREATED)
    public ConventionResponse generer(@PathVariable Long candidatureId) {
        return conventionService.generer(candidatureId);
    }
}