package com.devtec.gestionstages.controller;

import com.devtec.gestionstages.dto.ReferenceResponse;
import com.devtec.gestionstages.service.ReferenceService;
import java.util.List;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/** Listes déroulantes : compétences et niveaux d'études (accès public). */
@RestController
@RequestMapping("/api/references")
@RequiredArgsConstructor
public class ReferenceController {

    private final ReferenceService referenceService;

    @GetMapping("/competences")
    public List<ReferenceResponse> getCompetences() {
        return referenceService.getCompetences();
    }

    @GetMapping("/niveaux")
    public List<ReferenceResponse> getNiveaux() {
        return referenceService.getNiveaux();
    }
}