package com.devtec.gestionstages.controller;

import com.devtec.gestionstages.dto.ProjetStageRequest;
import com.devtec.gestionstages.dto.ProjetStageResponse;
import com.devtec.gestionstages.dto.TacheRequest;
import com.devtec.gestionstages.dto.TacheResponse;
import com.devtec.gestionstages.exception.AccesRefuseException;
import com.devtec.gestionstages.security.UtilisateurConnecte;
import com.devtec.gestionstages.service.ProjetStageService;
import jakarta.validation.Valid;
import java.util.List;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

/**
 * Cas « gérer projets » (Mentor) + catalogue des stages (public).
 *   GET    /api/projets                       catalogue (public)
 *   GET    /api/projets/{id}                  fiche projet (public)
 *   GET    /api/projets/mes-projets           projets du mentor connecté
 *   POST   /api/projets                       créer
 *   PUT    /api/projets/{id}                  modifier (seulement ses projets)
 *   DELETE /api/projets/{id}                  supprimer (seulement ses projets)
 *   POST   /api/projets/{id}/taches           ajouter une tâche
 *   DELETE /api/projets/{id}/taches/{tacheId} supprimer une tâche
 */
@RestController
@RequestMapping("/api/projets")
@RequiredArgsConstructor
public class ProjetStageController {

    private final ProjetStageService projetService;

    @GetMapping
    public List<ProjetStageResponse> findAll() {
        return projetService.findAll();
    }

    @GetMapping("/{id}")
    public ProjetStageResponse findById(@PathVariable Long id) {
        return projetService.findById(id);
    }

    /** Le mentor est lu dans le token JWT (Mentor 1 ---- 0..* ProjetStage). */
    @GetMapping("/mes-projets")
    public List<ProjetStageResponse> mesProjets(@AuthenticationPrincipal UtilisateurConnecte mentor) {
        return projetService.findByMentor(mentor.profilId());
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public ProjetStageResponse create(@Valid @RequestBody ProjetStageRequest request,
                                      @AuthenticationPrincipal UtilisateurConnecte mentor) {
        return projetService.create(avecMentor(request, mentor));
    }

    @PutMapping("/{id}")
    public ProjetStageResponse update(@PathVariable Long id,
                                      @Valid @RequestBody ProjetStageRequest request,
                                      @AuthenticationPrincipal UtilisateurConnecte mentor) {
        verifierProprietaire(id, mentor);
        return projetService.update(id, avecMentor(request, mentor));
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id, @AuthenticationPrincipal UtilisateurConnecte mentor) {
        verifierProprietaire(id, mentor);
        projetService.delete(id);
    }

    @PostMapping("/{id}/taches")
    @ResponseStatus(HttpStatus.CREATED)
    public TacheResponse addTache(@PathVariable Long id,
                                  @Valid @RequestBody TacheRequest request,
                                  @AuthenticationPrincipal UtilisateurConnecte mentor) {
        verifierProprietaire(id, mentor);
        return projetService.addTache(id, request.libelle());
    }

    @DeleteMapping("/{id}/taches/{tacheId}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void deleteTache(@PathVariable Long id,
                            @PathVariable Long tacheId,
                            @AuthenticationPrincipal UtilisateurConnecte mentor) {
        verifierProprietaire(id, mentor);
        projetService.deleteTache(id, tacheId);
    }

    // ------------------------------------------------------------------ Utilitaires

    /** Un mentor ne peut modifier que les projets qu'il encadre. */
    private void verifierProprietaire(Long projetId, UtilisateurConnecte mentor) {
        if (!projetService.appartientAuMentor(projetId, mentor.profilId())) {
            throw new AccesRefuseException("Ce projet est encadré par un autre mentor");
        }
    }

    /** Le mentor du projet est toujours le mentor connecté (on ignore celui envoyé par React). */
    private static ProjetStageRequest avecMentor(ProjetStageRequest r, UtilisateurConnecte mentor) {
        return new ProjetStageRequest(r.titre(), r.dateDebut(), r.dateFin(), r.objectifs(),
                mentor.profilId(), r.niveauIds(), r.competences(), r.taches());
    }
}