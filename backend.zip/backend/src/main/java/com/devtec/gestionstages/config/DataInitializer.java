package com.devtec.gestionstages.config;

import com.devtec.gestionstages.entity.Compte;
import com.devtec.gestionstages.repository.CompteRepository;
import java.util.List;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

/**
 * Au démarrage : hache en BCrypt les mots de passe encore en clair
 * (comptes de test du script SQL : admin123, rh123, mentor123).
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class DataInitializer implements CommandLineRunner {

    private final CompteRepository compteRepository;
    private final PasswordEncoder passwordEncoder;

    @Override
    @Transactional
    public void run(String... args) {
        List<Compte> enClair = compteRepository.findAll().stream()
                .filter(c -> !c.getMdp().startsWith("$2"))
                .toList();

        enClair.forEach(c -> {
            c.setMdp(passwordEncoder.encode(c.getMdp()));
            compteRepository.save(c);
        });

        if (!enClair.isEmpty()) {
            log.info("{} mot(s) de passe haché(s) en BCrypt", enClair.size());
        }
    }
}