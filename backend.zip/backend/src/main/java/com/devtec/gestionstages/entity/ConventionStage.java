package com.devtec.gestionstages.entity;

import jakarta.persistence.*;
import java.time.LocalDate;
import lombok.*;
import org.hibernate.annotations.Generated;

/**
 * Classe ConventionStage (numero, dateCreation) → table convention_stage.
 * Candidature 1 ---- 0..1 ConventionStage.
 *
 * Énoncé : identifiant unique composé de TROIS champs
 *   numSequentiel - mois de recrutement (1 ou 6) - annee      ex. 03-6-2026
 * L'attribut « numero » du diagramme est calculé par MySQL (colonne générée) :
 * Java ne l'écrit jamais, il le relit après l'INSERT grâce à @Generated.
 */
@Entity
@Table(name = "convention_stage")
@Getter
@Setter
@NoArgsConstructor
public class ConventionStage {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "num_sequentiel", nullable = false)
    private Integer numSequentiel;

    @Column(nullable = false, columnDefinition = "TINYINT")
    private Integer mois;

    @Column(nullable = false, columnDefinition = "SMALLINT")
    private Integer annee;

    /** Lecture seule : calculé par MySQL. */
    @Generated
    @Column(insertable = false, updatable = false, length = 20)
    private String numero;

    @Column(name = "date_creation", nullable = false)
    private LocalDate dateCreation;

    @OneToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "candidature_id", nullable = false, unique = true)
    private Candidature candidature;
}
