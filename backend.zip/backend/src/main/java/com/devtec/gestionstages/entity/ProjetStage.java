package com.devtec.gestionstages.entity;

import jakarta.persistence.*;
import java.time.LocalDate;
import java.util.*;
import lombok.*;

/**
 * Classe ProjetStage (titre, dateDebut, dateFin, objectifs) → table projet_stage.
 *  - Mentor 1 ---- 0..* ProjetStage
 *  - composition ◆ ProjetStage ---- 0..* Tâche
 *  - Compétence 0..* ---- 0..* ProjetStage via la classe d'association CompetenceProjet (poids)
 *  - ProjetStage 0..* ---- 1..* NiveauEtudes (niveaux souhaités)
 */
@Entity
@Table(name = "projet_stage")
@Getter
@Setter
@NoArgsConstructor
public class ProjetStage {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, length = 150)
    private String titre;

    @Column(name = "date_debut", nullable = false)
    private LocalDate dateDebut;

    @Column(name = "date_fin", nullable = false)
    private LocalDate dateFin;

    @Column(columnDefinition = "TEXT")
    private String objectifs;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "mentor_id", nullable = false)
    private Mentor mentor;

    /** Composition : supprimer le projet supprime ses tâches. */
    @OneToMany(mappedBy = "projet", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<Tache> taches = new ArrayList<>();

    @OneToMany(mappedBy = "projet", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<CompetenceProjet> competences = new ArrayList<>();

    @ManyToMany
    @JoinTable(name = "projet_niveau",
               joinColumns = @JoinColumn(name = "projet_id"),
               inverseJoinColumns = @JoinColumn(name = "niveau_id"))
    private Set<NiveauEtudes> niveauxSouhaites = new HashSet<>();

    // ----- Méthodes utilitaires (gardent les deux côtés de la relation cohérents) -----

    public void ajouterTache(Tache tache) {
        taches.add(tache);
        tache.setProjet(this);
    }

    public void retirerTache(Tache tache) {
        taches.remove(tache);
        tache.setProjet(null);
    }

    public void ajouterCompetence(Competence competence, int poids) {
        competences.add(new CompetenceProjet(competence, this, poids));
    }
}