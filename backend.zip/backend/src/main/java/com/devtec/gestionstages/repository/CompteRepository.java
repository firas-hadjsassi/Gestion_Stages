package com.devtec.gestionstages.repository;

import com.devtec.gestionstages.entity.Compte;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.Optional;

public interface CompteRepository extends JpaRepository<Compte, Long> {

    Optional<Compte> findByLogin(String login);

    boolean existsByLogin(String login);
}