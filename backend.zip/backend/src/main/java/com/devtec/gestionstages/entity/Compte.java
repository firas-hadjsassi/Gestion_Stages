package com.devtec.gestionstages.entity;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "compte")
@Getter
@Setter
@NoArgsConstructor
public class Compte {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, unique = true, length = 50)
    private String login;

    @Column(nullable = false)
    private String mdp;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, columnDefinition = "ENUM('ADMIN','RH','MENTOR')")
    private Role role;

    public Compte(String login, String mdp, Role role) {
        this.login = login;
        this.mdp = mdp;
        this.role = role;
    }
}