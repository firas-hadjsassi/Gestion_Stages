package com.devtec.gestionstages.repository;

import com.devtec.gestionstages.entity.NiveauEtudes;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.Optional;

public interface NiveauEtudesRepository extends JpaRepository<NiveauEtudes, Long> {

    Optional<NiveauEtudes> findByNiveau(String niveau);
}