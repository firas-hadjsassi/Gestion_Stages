package com.devtec.gestionstages.dto;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import java.time.LocalDate;
import java.util.List;
import java.util.Set;

/** Fiche de description de projet (Annexe 1) envoyée par React. */
public record ProjetStageRequest(

        @NotBlank(message = "Le titre est obligatoire")
        @Size(max = 150)
        String titre,

        @NotNull(message = "La date de début est obligatoire")
        LocalDate dateDebut,

        @NotNull(message = "La date de fin est obligatoire")
        LocalDate dateFin,

        String objectifs,

        /** Rempli par le serveur à partir du token du mentor connecté. */
        Long mentorId,

        /** Multiplicité 1..* vers NiveauEtudes. */
        @NotEmpty(message = "Au moins un niveau d'études est requis")
        Set<Long> niveauIds,

        @Valid
        List<CompetencePoidsRequest> competences,

        List<@NotBlank String> taches
) {}