package com.devtec.gestionstages.service;

import com.devtec.gestionstages.dto.ReferenceResponse;
import com.devtec.gestionstages.repository.CompetenceRepository;
import com.devtec.gestionstages.repository.NiveauEtudesRepository;
import java.util.Comparator;
import java.util.List;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/** Listes de référence : compétences et niveaux d'études. */
@Service
@RequiredArgsConstructor
@Transactional(readOnly = true)
public class ReferenceService {

    private final CompetenceRepository competenceRepository;
    private final NiveauEtudesRepository niveauEtudesRepository;

    public List<ReferenceResponse> getCompetences() {
        return competenceRepository.findAll().stream()
                .map(c -> new ReferenceResponse(c.getId(), c.getLibelle()))
                .sorted(Comparator.comparing(ReferenceResponse::libelle))
                .toList();
    }

    public List<ReferenceResponse> getNiveaux() {
        return niveauEtudesRepository.findAll().stream()
                .map(n -> new ReferenceResponse(n.getId(), n.getNiveau()))
                .sorted(Comparator.comparing(ReferenceResponse::id))
                .toList();
    }
}