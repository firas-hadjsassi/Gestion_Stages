package com.devtec.gestionstages.security;

import com.devtec.gestionstages.entity.Role;

/**
 * Utilisateur authentifié, reconstruit à partir du token JWT à chaque requête.
 * profilId = id de l'AgentRH ou du Mentor (null pour ADMIN).
 */
public record UtilisateurConnecte(Long compteId, String login, Role role, Long profilId) {}