package com.devtec.gestionstages.dto;

import com.devtec.gestionstages.entity.Tache;

public record TacheResponse(Long id, String libelle) {

    public static TacheResponse from(Tache t) {
        return new TacheResponse(t.getId(), t.getLibelle());
    }
}