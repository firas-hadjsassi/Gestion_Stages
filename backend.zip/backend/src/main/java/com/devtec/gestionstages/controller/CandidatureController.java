package com.devtec.gestionstages.controller;

import com.devtec.gestionstages.dto.CandidatureRequest;
import com.devtec.gestionstages.dto.CandidatureResponse;
import com.devtec.gestionstages.entity.StatutCandidature;
import com.devtec.gestionstages.service.CandidatureService;
import jakarta.validation.Valid;
import java.util.List;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

/**
 * Cas « soumettre candidature » (Candidat) et « gérer stagiaires » (Service RH).
 *   POST /api/candidatures                         soumettre (public)
 *   GET  /api/candidatures?projetId=&statut=       lister (RH)
 *   GET  /api/candidatures/projet/{projetId}/tri   tri automatique par score (RH)
 *   PUT  /api/candidatures/{id}/accepter           accepter (RH)
 *   PUT  /api/candidatures/{id}/refuser            refuser (RH)
 */
@RestController
@RequestMapping("/api/candidatures")
@RequiredArgsConstructor
public class CandidatureController {

    private final CandidatureService candidatureService;

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public CandidatureResponse soumettre(@Valid @RequestBody CandidatureRequest request) {
        return candidatureService.soumettre(request);
    }

    @GetMapping
    public List<CandidatureResponse> findAll(@RequestParam(required = false) Long projetId,
                                             @RequestParam(required = false) StatutCandidature statut) {
        return candidatureService.findAll(projetId, statut);
    }

    @GetMapping("/projet/{projetId}/tri")
    public List<CandidatureResponse> trierParScore(@PathVariable Long projetId) {
        return candidatureService.trierParScore(projetId);
    }

    @PutMapping("/{id}/accepter")
    public CandidatureResponse accepter(@PathVariable Long id) {
        return candidatureService.accepter(id);
    }

    @PutMapping("/{id}/refuser")
    public CandidatureResponse refuser(@PathVariable Long id) {
        return candidatureService.refuser(id);
    }
}