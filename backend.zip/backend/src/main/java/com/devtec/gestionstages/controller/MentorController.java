package com.devtec.gestionstages.controller;

import com.devtec.gestionstages.dto.MentorRequest;
import com.devtec.gestionstages.dto.MentorResponse;
import com.devtec.gestionstages.service.MentorService;
import jakarta.validation.Valid;
import java.util.List;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

/** Cas « gérer mentors » (Service RH) : CRUD /api/mentors. */
@RestController
@RequestMapping("/api/mentors")
@RequiredArgsConstructor
public class MentorController {

    private final MentorService mentorService;

    @GetMapping
    public List<MentorResponse> findAll() {
        return mentorService.findAll();
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public MentorResponse create(@Valid @RequestBody MentorRequest request) {
        return mentorService.create(request);
    }

    @PutMapping("/{id}")
    public MentorResponse update(@PathVariable Long id, @Valid @RequestBody MentorRequest request) {
        return mentorService.update(id, request);
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id) {
        mentorService.delete(id);
    }
}