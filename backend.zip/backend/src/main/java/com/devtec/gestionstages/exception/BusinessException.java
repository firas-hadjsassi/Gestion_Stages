package com.devtec.gestionstages.exception;

/** Règle métier non respectée (doublon, statut invalide…) → HTTP 400. */
public class BusinessException extends RuntimeException {

    public BusinessException(String message) {
        super(message);
    }
}