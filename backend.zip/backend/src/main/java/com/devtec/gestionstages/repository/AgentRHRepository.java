package com.devtec.gestionstages.repository;

import com.devtec.gestionstages.entity.AgentRH;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.Optional;

public interface AgentRHRepository extends JpaRepository<AgentRH, Long> {

    Optional<AgentRH> findByCompteId(Long compteId);
}