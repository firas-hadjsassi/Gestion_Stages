package com.devtec.gestionstages.security.config;

import com.devtec.gestionstages.security.jwt.JwtAuthFilter;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;
import lombok.RequiredArgsConstructor;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.CorsConfigurationSource;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;

/**
 * Sécurité selon le diagramme de cas d'utilisation :
 *  - Candidat (non authentifié) : catalogue, fiche projet, soumettre candidature
 *  - Mentor   : gérer projets                                         <<include>> s'authentifier
 *  - Service RH : gérer stagiaires, gérer mentors, gérer conventions  <<include>> s'authentifier
 *  - Administrateur : gérer comptes                                   <<include>> s'authentifier
 */
@Configuration
@EnableWebSecurity
@RequiredArgsConstructor
public class SecurityConfig {

    private final JwtAuthFilter jwtAuthFilter;

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http
            .csrf(csrf -> csrf.disable())
            .cors(Customizer.withDefaults())
            .sessionManagement(session -> session.sessionCreationPolicy(SessionCreationPolicy.STATELESS))
            .authorizeHttpRequests(auth -> auth
                // ----- Public -----
                .requestMatchers(HttpMethod.OPTIONS, "/**").permitAll()
                .requestMatchers("/error").permitAll()
                .requestMatchers(HttpMethod.POST, "/api/auth/login").permitAll()
                .requestMatchers(HttpMethod.GET, "/api/projets/mes-projets").hasRole("MENTOR")
                .requestMatchers(HttpMethod.GET, "/api/projets", "/api/projets/*", "/api/references/**").permitAll()
                .requestMatchers(HttpMethod.POST, "/api/candidatures").permitAll()
                // ----- Mentor : gérer projets -----
                .requestMatchers("/api/projets/**").hasRole("MENTOR")
                // ----- Service RH : gérer stagiaires, mentors, conventions -----
                .requestMatchers("/api/candidatures/**", "/api/conventions/**", "/api/mentors/**").hasRole("RH")
                // ----- Administrateur : gérer comptes -----
                .requestMatchers("/api/comptes/**").hasRole("ADMIN")
                .anyRequest().authenticated())
            .exceptionHandling(erreurs -> erreurs
                .authenticationEntryPoint((request, response, ex) ->
                        ecrireErreur(response, 401, "Authentification requise"))
                .accessDeniedHandler((request, response, ex) ->
                        ecrireErreur(response, 403, "Accès refusé pour votre rôle")))
            .addFilterBefore(jwtAuthFilter, UsernamePasswordAuthenticationFilter.class);

        return http.build();
    }

    /** CORS : autorise le frontend React lancé en local (Vite, port 5173 par défaut). */
    @Bean
    public CorsConfigurationSource corsConfigurationSource() {
        CorsConfiguration config = new CorsConfiguration();
        // Toute adresse locale : Vite peut démarrer sur 5174 si 5173 est déjà pris
        config.setAllowedOriginPatterns(List.of("http://localhost:*", "http://127.0.0.1:*"));
        config.setAllowedMethods(List.of("GET", "POST", "PUT", "DELETE", "OPTIONS"));
        config.setAllowedHeaders(List.of("*"));
        config.setAllowCredentials(true);

        UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
        source.registerCorsConfiguration("/api/**", config);
        return source;
    }

    private static void ecrireErreur(HttpServletResponse response, int status, String message) throws IOException {
        response.setStatus(status);
        response.setContentType("application/json;charset=UTF-8");
        response.getWriter().write("{\"status\":" + status + ",\"message\":\"" + message + "\"}");
    }
}