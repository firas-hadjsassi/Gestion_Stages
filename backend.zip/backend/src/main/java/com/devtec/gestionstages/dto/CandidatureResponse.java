package com.devtec.gestionstages.dto;

import com.devtec.gestionstages.entity.Candidature;
import com.devtec.gestionstages.entity.Competence;
import com.devtec.gestionstages.entity.StatutCandidature;
import java.time.LocalDate;
import java.util.List;

public record CandidatureResponse(
        Long id,
        String nomCandidat,
        String email,
        LocalDate dateCandidature,
        StatutCandidature statut,
        Long projetId,
        String projetTitre,
        String niveau,
        List<String> competences,
        double score
) {
    public static CandidatureResponse from(Candidature c) {
        return new CandidatureResponse(
                c.getId(),
                c.getNomCandidat(),
                c.getEmail(),
                c.getDateCandidature(),
                c.getStatut(),
                c.getProjet().getId(),
                c.getProjet().getTitre(),
                c.getNiveau().getNiveau(),
                c.getCompetences().stream().map(Competence::getLibelle).sorted().toList(),
                c.getScore());
    }
}