package com.devtec.gestionstages.dto;

import com.devtec.gestionstages.entity.CompetenceProjet;

public record CompetencePoidsResponse(Long competenceId, String libelle, int poids) {

    public static CompetencePoidsResponse from(CompetenceProjet cp) {
        return new CompetencePoidsResponse(
                cp.getCompetence().getId(),
                cp.getCompetence().getLibelle(),
                cp.getPoids());
    }
}