package com.devtec.gestionstages.entity;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "agent_rh")
@Getter
@Setter
@NoArgsConstructor
public class AgentRH {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, length = 100)
    private String nom;

    @OneToOne(optional = false, cascade = CascadeType.ALL)
    @JoinColumn(name = "compte_id", nullable = false, unique = true)
    private Compte compte;
}