package com.devtec.gestionstages.exception;

/** Action interdite pour l'utilisateur connecté (ex. projet d'un autre mentor) → HTTP 403. */
public class AccesRefuseException extends RuntimeException {

    public AccesRefuseException(String message) {
        super(message);
    }
}