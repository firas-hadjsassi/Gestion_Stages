package com.devtec.gestionstages.controller;

import com.devtec.gestionstages.dto.CompteRequest;
import com.devtec.gestionstages.dto.CompteResponse;
import com.devtec.gestionstages.dto.MotDePasseRequest;
import com.devtec.gestionstages.service.CompteService;
import jakarta.validation.Valid;
import java.util.List;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

/**
 * Cas « gérer comptes » (Administrateur) : création des comptes et attribution des rôles.
 *   GET    /api/comptes
 *   POST   /api/comptes
 *   PUT    /api/comptes/{id}/mdp
 *   DELETE /api/comptes/{id}
 */
@RestController
@RequestMapping("/api/comptes")
@RequiredArgsConstructor
public class CompteController {

    private final CompteService compteService;

    @GetMapping
    public List<CompteResponse> findAll() {
        return compteService.findAll();
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public CompteResponse create(@Valid @RequestBody CompteRequest request) {
        return compteService.create(request);
    }

    @PutMapping("/{id}/mdp")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void changerMotDePasse(@PathVariable Long id, @Valid @RequestBody MotDePasseRequest request) {
        compteService.changerMotDePasse(id, request.mdp());
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id) {
        compteService.delete(id);
    }
}