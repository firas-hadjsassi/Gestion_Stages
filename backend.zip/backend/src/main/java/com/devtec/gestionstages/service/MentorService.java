package com.devtec.gestionstages.service;

import com.devtec.gestionstages.dto.MentorRequest;
import com.devtec.gestionstages.dto.MentorResponse;
import com.devtec.gestionstages.entity.Compte;
import com.devtec.gestionstages.entity.Mentor;
import com.devtec.gestionstages.entity.Role;
import com.devtec.gestionstages.exception.BusinessException;
import com.devtec.gestionstages.exception.ResourceNotFoundException;
import com.devtec.gestionstages.repository.CompteRepository;
import com.devtec.gestionstages.repository.MentorRepository;
import com.devtec.gestionstages.repository.ProjetStageRepository;
import java.util.Comparator;
import java.util.List;
import lombok.RequiredArgsConstructor;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/** Cas « gérer mentors » (service RH) : un mentor est toujours créé avec son compte MENTOR. */
@Service
@RequiredArgsConstructor
@Transactional
public class MentorService {

    private final MentorRepository mentorRepository;
    private final CompteRepository compteRepository;
    private final ProjetStageRepository projetRepository;
    private final PasswordEncoder passwordEncoder;

    @Transactional(readOnly = true)
    public List<MentorResponse> findAll() {
        return mentorRepository.findAll().stream()
                .sorted(Comparator.comparing(Mentor::getNom))
                .map(MentorResponse::from)
                .toList();
    }

    public MentorResponse create(MentorRequest req) {
        String login = req.login().trim();
        if (compteRepository.existsByLogin(login)) {
            throw new BusinessException("Le login « " + login + " » est déjà utilisé");
        }
        if (req.mdp() == null || req.mdp().length() < 4) {
            throw new BusinessException("Le mot de passe doit contenir au moins 4 caractères");
        }

        Mentor mentor = new Mentor();
        mentor.setNom(req.nom().trim());
        mentor.setSpecialite(req.specialite());
        mentor.setCompte(new Compte(login, passwordEncoder.encode(req.mdp()), Role.MENTOR));

        return MentorResponse.from(mentorRepository.save(mentor));   // cascade : le compte est créé aussi
    }

    public MentorResponse update(Long id, MentorRequest req) {
        Mentor mentor = getMentor(id);
        Compte compte = mentor.getCompte();

        String login = req.login().trim();
        if (!login.equals(compte.getLogin()) && compteRepository.existsByLogin(login)) {
            throw new BusinessException("Le login « " + login + " » est déjà utilisé");
        }

        mentor.setNom(req.nom().trim());
        mentor.setSpecialite(req.specialite());
        compte.setLogin(login);

        if (req.mdp() != null && !req.mdp().isBlank()) {
            if (req.mdp().length() < 4) {
                throw new BusinessException("Le mot de passe doit contenir au moins 4 caractères");
            }
            compte.setMdp(passwordEncoder.encode(req.mdp()));
        }
        return MentorResponse.from(mentor);
    }

    public void delete(Long id) {
        Mentor mentor = getMentor(id);
        if (!projetRepository.findByMentorId(id).isEmpty()) {
            throw new BusinessException("Impossible de supprimer ce mentor : il encadre encore des projets");
        }
        mentorRepository.delete(mentor);                 // cascade : le compte est supprimé aussi
    }

    private Mentor getMentor(Long id) {
        return mentorRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Mentor", id));
    }
}