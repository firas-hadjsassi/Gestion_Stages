package com.devtec.gestionstages.service;

import com.devtec.gestionstages.dto.CandidatureRequest;
import com.devtec.gestionstages.dto.CandidatureResponse;
import com.devtec.gestionstages.entity.Candidature;
import com.devtec.gestionstages.entity.Competence;
import com.devtec.gestionstages.entity.CompetenceProjet;
import com.devtec.gestionstages.entity.NiveauEtudes;
import com.devtec.gestionstages.entity.ProjetStage;
import com.devtec.gestionstages.entity.StatutCandidature;
import com.devtec.gestionstages.exception.BusinessException;
import com.devtec.gestionstages.exception.ResourceNotFoundException;
import com.devtec.gestionstages.repository.CandidatureRepository;
import com.devtec.gestionstages.repository.CompetenceRepository;
import com.devtec.gestionstages.repository.NiveauEtudesRepository;
import com.devtec.gestionstages.repository.ProjetStageRepository;
import java.time.LocalDate;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * Soumission des candidatures et tri automatique (énoncé : tri selon le niveau d'études
 * et la correspondance avec les requis du projet).
 *
 * Calcul de l'attribut dérivé /score (sur 100) :
 *  - 30 points si le niveau d'études du candidat fait partie des niveaux souhaités du projet ;
 *  - 70 points répartis selon les compétences requises, au prorata de leur poids
 *    (somme des poids des compétences que le candidat possède / somme totale des poids).
 */
@Service
@RequiredArgsConstructor
@Transactional
public class CandidatureService {

    public static final double POINTS_NIVEAU = 30.0;
    public static final double POINTS_COMPETENCES = 70.0;

    private final CandidatureRepository candidatureRepository;
    private final ProjetStageRepository projetRepository;
    private final NiveauEtudesRepository niveauRepository;
    private final CompetenceRepository competenceRepository;

    // ------------------------------------------------------------------ Candidat

    /** Cas d'utilisation « soumettre candidature ». */
    public CandidatureResponse soumettre(CandidatureRequest req) {
        ProjetStage projet = projetRepository.findById(req.projetId())
                .orElseThrow(() -> new ResourceNotFoundException("Projet", req.projetId()));

        if (!LocalDate.now().isBefore(projet.getDateDebut())) {
            throw new BusinessException("Les candidatures pour ce projet sont closes");
        }

        String email = req.email().trim().toLowerCase();
        if (candidatureRepository.existsByEmailAndProjetId(email, projet.getId())) {
            throw new BusinessException("Vous avez déjà postulé à ce projet avec cet email");
        }

        NiveauEtudes niveau = niveauRepository.findById(req.niveauId())
                .orElseThrow(() -> new ResourceNotFoundException("Niveau d'études", req.niveauId()));

        List<Competence> competences = competenceRepository.findAllById(req.competenceIds());
        if (competences.size() != req.competenceIds().size()) {
            throw new ResourceNotFoundException("Une des compétences est introuvable");
        }

        Candidature c = new Candidature();
        c.setNomCandidat(req.nomCandidat().trim());
        c.setEmail(email);
        c.setDateCandidature(LocalDate.now());
        c.setStatut(StatutCandidature.EN_ATTENTE);
        c.setProjet(projet);
        c.setNiveau(niveau);
        c.setCompetences(new HashSet<>(competences));

        c = candidatureRepository.save(c);
        c.setScore(calculerScore(c));
        return CandidatureResponse.from(c);
    }

    // ------------------------------------------------------------------ Service RH

    /** Liste filtrable par projet et/ou statut (paramètres facultatifs). */
    @Transactional(readOnly = true)
    public List<CandidatureResponse> findAll(Long projetId, StatutCandidature statut) {
        List<Candidature> candidatures = projetId != null
                ? candidatureRepository.findByProjetId(projetId)
                : candidatureRepository.findAll();

        candidatures.forEach(c -> c.setScore(calculerScore(c)));

        return candidatures.stream()
                .filter(c -> statut == null || c.getStatut() == statut)
                .sorted(Comparator.comparing(Candidature::getDateCandidature).reversed())
                .map(CandidatureResponse::from)
                .toList();
    }

    /** Tri automatique : score décroissant, puis date de candidature (premier arrivé). */
    @Transactional(readOnly = true)
    public List<CandidatureResponse> trierParScore(Long projetId) {
        if (!projetRepository.existsById(projetId)) {
            throw new ResourceNotFoundException("Projet", projetId);
        }
        return trier(candidatureRepository.findByProjetId(projetId)).stream()
                .map(CandidatureResponse::from)
                .toList();
    }

    public CandidatureResponse accepter(Long id) {
        return changerStatut(id, StatutCandidature.ACCEPTEE);
    }

    public CandidatureResponse refuser(Long id) {
        return changerStatut(id, StatutCandidature.REFUSEE);
    }

    // ------------------------------------------------------------------ Règles métier (testées avec JUnit)

    /** Calcule l'attribut dérivé /score d'une candidature (entre 0 et 100). */
    public double calculerScore(Candidature c) {
        ProjetStage projet = c.getProjet();

        double score = 0;

        // 1. Niveau d'études
        boolean niveauSouhaite = projet.getNiveauxSouhaites().stream()
                .anyMatch(n -> n.getId().equals(c.getNiveau().getId()));
        if (niveauSouhaite) {
            score += POINTS_NIVEAU;
        }

        // 2. Compétences pondérées
        Set<Long> competencesCandidat = new HashSet<>();
        c.getCompetences().forEach(comp -> competencesCandidat.add(comp.getId()));

        int poidsTotal = 0;
        int poidsObtenu = 0;
        for (CompetenceProjet cp : projet.getCompetences()) {
            poidsTotal += cp.getPoids();
            if (competencesCandidat.contains(cp.getCompetence().getId())) {
                poidsObtenu += cp.getPoids();
            }
        }
        score += poidsTotal == 0
                ? POINTS_COMPETENCES
                : POINTS_COMPETENCES * poidsObtenu / poidsTotal;

        return Math.round(score * 10) / 10.0;            // arrondi à 0,1
    }

    /** Calcule le score de chaque candidature puis les classe. */
    public List<Candidature> trier(List<Candidature> candidatures) {
        candidatures.forEach(c -> c.setScore(calculerScore(c)));
        return candidatures.stream()
                .sorted(Comparator.comparingDouble(Candidature::getScore).reversed()
                        .thenComparing(Candidature::getDateCandidature))
                .toList();
    }

    // ------------------------------------------------------------------ Utilitaires

    private CandidatureResponse changerStatut(Long id, StatutCandidature nouveau) {
        Candidature c = candidatureRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Candidature", id));
        if (c.getStatut() != StatutCandidature.EN_ATTENTE) {
            throw new BusinessException("Cette candidature a déjà été traitée (" + c.getStatut() + ")");
        }
        c.setStatut(nouveau);
        c.setScore(calculerScore(c));
        return CandidatureResponse.from(c);
    }
}