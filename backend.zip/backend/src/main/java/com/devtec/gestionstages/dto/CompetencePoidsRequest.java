package com.devtec.gestionstages.dto;

import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;

/** Compétence requise par un projet avec son poids (classe d'association CompetenceProjet). */
public record CompetencePoidsRequest(

        @NotNull(message = "La compétence est obligatoire")
        Long competenceId,

        @Min(value = 1, message = "Le poids doit être au moins 1")
        int poids
) {}