package com.devtec.gestionstages.exception;

/** Login ou mot de passe incorrect → HTTP 401. */
public class AuthentificationException extends RuntimeException {

    public AuthentificationException(String message) {
        super(message);
    }
}