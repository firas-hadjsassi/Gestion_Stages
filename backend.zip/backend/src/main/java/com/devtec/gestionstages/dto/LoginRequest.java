package com.devtec.gestionstages.dto;

import jakarta.validation.constraints.NotBlank;

/** Cas « s'authentifier » : identifiants saisis dans la page de connexion. */
public record LoginRequest(

        @NotBlank(message = "Le login est obligatoire")
        String login,

        @NotBlank(message = "Le mot de passe est obligatoire")
        String mdp
) {}