package com.devtec.gestionstages.dto;

import com.devtec.gestionstages.entity.Role;

/**
 * Réponse de connexion envoyée à React.
 * profilId = id de l'AgentRH ou du Mentor lié au compte (null pour ADMIN).
 */
public record LoginResponse(String token, String login, Role role, String nom, Long profilId) {}