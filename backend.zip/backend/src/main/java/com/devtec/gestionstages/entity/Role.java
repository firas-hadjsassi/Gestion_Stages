package com.devtec.gestionstages.entity;

public enum Role {
    ADMIN, RH, MENTOR
}