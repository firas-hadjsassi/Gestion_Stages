package com.devtec.gestionstages.dto;

import com.devtec.gestionstages.entity.Mentor;

public record MentorResponse(Long id, String nom, String specialite, String login) {

    public static MentorResponse from(Mentor m) {
        return new MentorResponse(m.getId(), m.getNom(), m.getSpecialite(), m.getCompte().getLogin());
    }
}