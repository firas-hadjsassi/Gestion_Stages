package com.devtec.gestionstages.repository;

import com.devtec.gestionstages.entity.ConventionStage;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface ConventionStageRepository extends JpaRepository<ConventionStage, Long> {

    /** Candidature 1 ---- 0..1 ConventionStage. */
    Optional<ConventionStage> findByCandidatureId(Long candidatureId);

    /** Plus grand numéro séquentiel d'une session (mois 1 ou 6 d'une année) ; 0 s'il n'y en a aucun. */
    @Query("""
           SELECT COALESCE(MAX(c.numSequentiel), 0)
           FROM ConventionStage c
           WHERE c.mois = :mois AND c.annee = :annee
           """)
    int findMaxNumSequentiel(@Param("mois") int mois, @Param("annee") int annee);
}
