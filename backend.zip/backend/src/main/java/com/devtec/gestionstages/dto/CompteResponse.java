package com.devtec.gestionstages.dto;

import com.devtec.gestionstages.entity.Role;

/** Compte renvoyé à React : le mot de passe n'est jamais renvoyé. */
public record CompteResponse(Long id, String login, Role role, String nom) {}