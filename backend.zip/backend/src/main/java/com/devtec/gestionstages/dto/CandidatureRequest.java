package com.devtec.gestionstages.dto;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import java.util.Set;

/** Formulaire « soumettre candidature » rempli par le candidat. */
public record CandidatureRequest(

        @NotBlank(message = "Le nom est obligatoire")
        @Size(max = 100)
        String nomCandidat,

        @NotBlank(message = "L'email est obligatoire")
        @Email(message = "Email invalide")
        String email,

        @NotNull(message = "Le projet est obligatoire")
        Long projetId,

        @NotNull(message = "Le niveau d'études est obligatoire")
        Long niveauId,

        /** Multiplicité 1..* vers Compétence. */
        @NotEmpty(message = "Indiquez au moins une compétence")
        Set<Long> competenceIds
) {}