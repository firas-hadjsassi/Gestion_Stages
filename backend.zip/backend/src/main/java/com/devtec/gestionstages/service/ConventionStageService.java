package com.devtec.gestionstages.service;

import com.devtec.gestionstages.dto.ConventionResponse;
import com.devtec.gestionstages.entity.Candidature;
import com.devtec.gestionstages.entity.ConventionStage;
import com.devtec.gestionstages.entity.StatutCandidature;
import com.devtec.gestionstages.exception.BusinessException;
import com.devtec.gestionstages.exception.ResourceNotFoundException;
import com.devtec.gestionstages.repository.CandidatureRepository;
import com.devtec.gestionstages.repository.ConventionStageRepository;
import java.time.LocalDate;
import java.util.Comparator;
import java.util.List;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * Cas « gérer conventions ».
 * Énoncé : identifiant unique = numéro séquentiel - mois de recrutement (1 ou 6) - année. Ex. 03-6-2026.
 */
@Service
@RequiredArgsConstructor
@Transactional
public class ConventionStageService {

    private final ConventionStageRepository conventionRepository;
    private final CandidatureRepository candidatureRepository;

    @Transactional(readOnly = true)
    public List<ConventionResponse> findAll() {
        return conventionRepository.findAll().stream()
                .sorted(Comparator.comparing(ConventionStage::getDateCreation)
                        .thenComparing(ConventionStage::getId))
                .map(ConventionResponse::from)
                .toList();
    }

    @Transactional(readOnly = true)
    public ConventionResponse findById(Long id) {
        return conventionRepository.findById(id)
                .map(ConventionResponse::from)
                .orElseThrow(() -> new ResourceNotFoundException("Convention", id));
    }

    /** Génère la convention d'une candidature acceptée (Candidature 1 ---- 0..1 ConventionStage). */
    public ConventionResponse generer(Long candidatureId) {
        Candidature candidature = candidatureRepository.findById(candidatureId)
                .orElseThrow(() -> new ResourceNotFoundException("Candidature", candidatureId));

        if (candidature.getStatut() != StatutCandidature.ACCEPTEE) {
            throw new BusinessException("Seule une candidature acceptée peut avoir une convention");
        }
        if (conventionRepository.findByCandidatureId(candidatureId).isPresent()) {
            throw new BusinessException("Une convention existe déjà pour ce stagiaire");
        }

        LocalDate debutStage = candidature.getProjet().getDateDebut();
        int mois = moisRecrutement(debutStage);
        int annee = debutStage.getYear();

        ConventionStage convention = new ConventionStage();
        convention.setNumSequentiel(prochainNumeroSequentiel(mois, annee));
        convention.setMois(mois);
        convention.setAnnee(annee);              // « numero » est calculé par MySQL
        convention.setDateCreation(LocalDate.now());
        convention.setCandidature(candidature);

        return ConventionResponse.from(conventionRepository.save(convention));
    }

    // ------------------------------------------------------------------ Règles métier (testées avec JUnit)

    /**
     * Numéro séquentiel suivant pour une session, ex. 2 conventions déjà en juin 2026 → 3.
     * On part du MAX (et non du nombre de conventions) : pas de doublon même s'il y a un trou.
     */
    public int prochainNumeroSequentiel(int mois, int annee) {
        if (mois != 1 && mois != 6) {
            throw new IllegalArgumentException("Le mois de recrutement doit être 1 ou 6");
        }
        return conventionRepository.findMaxNumSequentiel(mois, annee) + 1;
    }

    /** Session de recrutement : janvier (1) pour un stage qui débute entre janvier et mai, sinon juin (6). */
    public static int moisRecrutement(LocalDate debutStage) {
        return debutStage.getMonthValue() < 6 ? 1 : 6;
    }

    /** Format NN-M-AAAA (2 chiffres minimum) : identique à la colonne générée par MySQL. */
    public static String formaterNumero(int sequence, int mois, int annee) {
        if (sequence < 1) {
            throw new IllegalArgumentException("Le numéro séquentiel doit être positif");
        }
        if (mois != 1 && mois != 6) {
            throw new IllegalArgumentException("Le mois de recrutement doit être 1 ou 6");
        }
        return String.format("%02d-%d-%d", sequence, mois, annee);
    }
}