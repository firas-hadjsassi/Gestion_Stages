package com.devtec.gestionstages.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;
import java.io.Serializable;
import lombok.*;

/** Clé primaire composée (competence_id, projet_id) de la table competence_projet. */
@Embeddable
@Getter
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode
public class CompetenceProjetId implements Serializable {

    @Column(name = "competence_id")
    private Long competenceId;

    @Column(name = "projet_id")
    private Long projetId;
}