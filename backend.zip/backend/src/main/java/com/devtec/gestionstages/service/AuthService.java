package com.devtec.gestionstages.service;

import com.devtec.gestionstages.dto.LoginRequest;
import com.devtec.gestionstages.dto.LoginResponse;
import com.devtec.gestionstages.entity.AgentRH;
import com.devtec.gestionstages.entity.Compte;
import com.devtec.gestionstages.entity.Mentor;
import com.devtec.gestionstages.exception.AuthentificationException;
import com.devtec.gestionstages.exception.BusinessException;
import com.devtec.gestionstages.repository.AgentRHRepository;
import com.devtec.gestionstages.repository.CompteRepository;
import com.devtec.gestionstages.repository.MentorRepository;
import com.devtec.gestionstages.security.UtilisateurConnecte;
import com.devtec.gestionstages.security.jwt.JwtService;
import lombok.RequiredArgsConstructor;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/** Cas « s'authentifier » : vérifie login + mot de passe (BCrypt) et génère le token JWT. */
@Service
@RequiredArgsConstructor
@Transactional(readOnly = true)
public class AuthService {

    private final CompteRepository compteRepository;
    private final AgentRHRepository agentRHRepository;
    private final MentorRepository mentorRepository;
    private final PasswordEncoder passwordEncoder;
    private final JwtService jwtService;

    public LoginResponse login(LoginRequest req) {
        Compte compte = compteRepository.findByLogin(req.login().trim())
                .filter(c -> passwordEncoder.matches(req.mdp(), c.getMdp()))
                .orElseThrow(() -> new AuthentificationException("Login ou mot de passe incorrect"));

        // {XOR} : le compte est lié à un AgentRH OU à un Mentor (aucun pour ADMIN)
        Long profilId = null;
        String nom;
        switch (compte.getRole()) {
            case RH -> {
                AgentRH agent = agentRHRepository.findByCompteId(compte.getId())
                        .orElseThrow(() -> new BusinessException("Compte RH sans agent RH associé"));
                profilId = agent.getId();
                nom = agent.getNom();
            }
            case MENTOR -> {
                Mentor mentor = mentorRepository.findByCompteId(compte.getId())
                        .orElseThrow(() -> new BusinessException("Compte MENTOR sans mentor associé"));
                profilId = mentor.getId();
                nom = mentor.getNom();
            }
            default -> nom = "Administrateur";
        }

        UtilisateurConnecte utilisateur =
                new UtilisateurConnecte(compte.getId(), compte.getLogin(), compte.getRole(), profilId);

        return new LoginResponse(jwtService.genererToken(utilisateur),
                compte.getLogin(), compte.getRole(), nom, profilId);
    }
}