package com.devtec.gestionstages.dto;

import com.devtec.gestionstages.entity.Candidature;
import com.devtec.gestionstages.entity.ConventionStage;
import com.devtec.gestionstages.entity.ProjetStage;
import java.time.LocalDate;

/** Convention de stage (Annexe 2) : stagiaire, projet, mentor. */
public record ConventionResponse(
        Long id,
        String numero,
        LocalDate dateCreation,
        Long candidatureId,
        String stagiaire,
        String emailStagiaire,
        String projetTitre,
        String objectifs,
        LocalDate dateDebut,
        LocalDate dateFin,
        String mentorNom,
        String mentorSpecialite
) {
    public static ConventionResponse from(ConventionStage cs) {
        Candidature c = cs.getCandidature();
        ProjetStage p = c.getProjet();
        return new ConventionResponse(
                cs.getId(),
                cs.getNumero(),
                cs.getDateCreation(),
                c.getId(),
                c.getNomCandidat(),
                c.getEmail(),
                p.getTitre(),
                p.getObjectifs(),
                p.getDateDebut(),
                p.getDateFin(),
                p.getMentor().getNom(),
                p.getMentor().getSpecialite());
    }
}