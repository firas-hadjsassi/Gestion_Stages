package com.devtec.gestionstages.repository;

import com.devtec.gestionstages.entity.ProjetStage;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface ProjetStageRepository extends JpaRepository<ProjetStage, Long> {

    /** Projets encadrés par un mentor (Mentor 1 ---- 0..* ProjetStage). */
    List<ProjetStage> findByMentorId(Long mentorId);
}