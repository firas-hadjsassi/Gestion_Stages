package com.devtec.gestionstages.dto;

import com.devtec.gestionstages.entity.Role;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

/**
 * Création d'un compte par l'administrateur.
 * Selon le rôle, le service crée aussi l'AgentRH (RH) ou le Mentor (MENTOR) : contrainte {XOR}.
 */
public record CompteRequest(

        @NotBlank(message = "Le login est obligatoire")
        @Size(max = 50)
        String login,

        @NotBlank(message = "Le mot de passe est obligatoire")
        @Size(min = 4, message = "Le mot de passe doit contenir au moins 4 caractères")
        String mdp,

        @NotNull(message = "Le rôle est obligatoire")
        Role role,

        /** Nom de l'agent RH ou du mentor (ignoré pour ADMIN). */
        String nom,

        /** Spécialité du mentor (ignorée pour les autres rôles). */
        String specialite
) {}