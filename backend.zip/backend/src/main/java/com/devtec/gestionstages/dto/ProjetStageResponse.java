package com.devtec.gestionstages.dto;

import com.devtec.gestionstages.entity.NiveauEtudes;
import com.devtec.gestionstages.entity.ProjetStage;
import java.time.LocalDate;
import java.util.List;

/** Projet renvoyé à React (catalogue des stages, fiche projet). */
public record ProjetStageResponse(
        Long id,
        String titre,
        LocalDate dateDebut,
        LocalDate dateFin,
        String objectifs,
        Long mentorId,
        String mentorNom,
        List<String> niveaux,
        List<CompetencePoidsResponse> competences,
        List<TacheResponse> taches
) {
    public static ProjetStageResponse from(ProjetStage p) {
        return new ProjetStageResponse(
                p.getId(),
                p.getTitre(),
                p.getDateDebut(),
                p.getDateFin(),
                p.getObjectifs(),
                p.getMentor().getId(),
                p.getMentor().getNom(),
                p.getNiveauxSouhaites().stream().map(NiveauEtudes::getNiveau).sorted().toList(),
                p.getCompetences().stream().map(CompetencePoidsResponse::from).toList(),
                p.getTaches().stream().map(TacheResponse::from).toList());
    }
}