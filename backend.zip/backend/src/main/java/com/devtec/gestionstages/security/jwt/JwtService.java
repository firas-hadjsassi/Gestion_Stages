package com.devtec.gestionstages.security.jwt;

import com.devtec.gestionstages.entity.Role;
import com.devtec.gestionstages.security.UtilisateurConnecte;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.JwtBuilder;
import io.jsonwebtoken.JwtException;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.security.Keys;
import java.nio.charset.StandardCharsets;
import java.util.Date;
import javax.crypto.SecretKey;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

/** Création et lecture des tokens JWT (signés HMAC-SHA avec jwt.secret). */
@Service
public class JwtService {

    private final SecretKey cle;
    private final long expiration;

    public JwtService(@Value("${jwt.secret}") String secret,
                      @Value("${jwt.expiration}") long expiration) {
        this.cle = Keys.hmacShaKeyFor(secret.getBytes(StandardCharsets.UTF_8));
        this.expiration = expiration;
    }

    /** Génère le token renvoyé à React après une connexion réussie. */
    public String genererToken(UtilisateurConnecte utilisateur) {
        Date maintenant = new Date();
        JwtBuilder builder = Jwts.builder()
                .subject(utilisateur.login())
                .claim("compteId", utilisateur.compteId())
                .claim("role", utilisateur.role().name())
                .issuedAt(maintenant)
                .expiration(new Date(maintenant.getTime() + expiration));
        if (utilisateur.profilId() != null) {
            builder.claim("profilId", utilisateur.profilId());
        }
        return builder.signWith(cle).compact();
    }

    /** Lit un token : renvoie l'utilisateur, ou null si le token est invalide ou expiré. */
    public UtilisateurConnecte lireToken(String token) {
        try {
            Claims claims = Jwts.parser().verifyWith(cle).build()
                    .parseSignedClaims(token)
                    .getPayload();
            return new UtilisateurConnecte(
                    enLong(claims.get("compteId")),
                    claims.getSubject(),
                    Role.valueOf(claims.get("role", String.class)),
                    enLong(claims.get("profilId")));
        } catch (JwtException | IllegalArgumentException e) {
            return null;
        }
    }

    private static Long enLong(Object valeur) {
        return valeur instanceof Number n ? n.longValue() : null;
    }
}